#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "mpi.h"
#include "global.h"
#include "ga.h"
#include "macdecls.h"
#include "search.h"
#include "write.h"

#define DEBUG 0

int main(int argc, char **argv)
{
	/* Simulation parameters */
	const int total_num_galaxy = 33887;
	const int write_line = 100;
	const char* infn = "galaxy_pos.txt";
	const char* outfn = "galaxy_density.txt";

	/* Variables */
	int total_num_nodes, my_node_id, total_num_procs, num_proc, my_proc_id, first_proc;
	int prev_l, prev_elem;
	FILE *infd;
	float dummy_x, dummy_y, dummy_z, dummy_mass;
	double temp_double;
	int temp_arr[1] = {total_num_galaxy};
	int temp_arr1[1], temp_arr2[1], temp_arr3[1];
	int chunk[1] = {1};
	// l, m, n are cell indicies for x, y, and z axis.
	int i, j, k, l, m, n, temp_int, dummy_id;
	float float_buf[1], float_buf1[1], float_buf2[1], float_buf3[1], float_buf4[1];
	int g_a_id, g_a_x, g_a_y, g_a_z, g_a_mass, g_a_neigh, g_a_tot_mass;
	int *ind_temp;
	// 1st elem = starting ind, 2nd elem = ending ind
	int arr_l[dim_cell*dim_cell*dim_cell];
	int arr_u[dim_cell*dim_cell*dim_cell];

	/* Initialization */
	MPI_Init(&argc, &argv);
	GA_Initialize();

	total_num_nodes = GA_Cluster_nnodes();
	my_node_id = GA_Cluster_nodeid();
	num_proc = GA_Cluster_nprocs(my_node_id);
	first_proc = GA_Cluster_procid(my_node_id, 0);
	GA_Sync();

	MPI_Comm_rank(MPI_COMM_WORLD, &my_proc_id);
	MPI_Comm_size(MPI_COMM_WORLD, &total_num_procs);
	if (my_proc_id == 0) {
		printf("# %d computing nodes with %d processors\n", total_num_nodes, total_num_procs);
		fflush(stdout);
	}
	MPI_Barrier(MPI_COMM_WORLD);
	if (my_proc_id == first_proc) {
		printf("# Node = %d / %d with %d processors\n", my_node_id, total_num_nodes, num_proc);
		fflush(stdout);
	}

	/* Initialization of array */
	for(i=0; i < dim_cell*dim_cell*dim_cell; i++) {
		arr_u[i] = 0;
		arr_l[i] = 0;
	}

	/* Creating arrays for galaxy data */
	g_a_id = NGA_Create(MT_INT, 1, temp_arr, "id", chunk);
	g_a_x = NGA_Create(MT_REAL, 1, temp_arr, "x", chunk);
	g_a_y = NGA_Create(MT_REAL, 1, temp_arr, "y", chunk);
	g_a_z = NGA_Create(MT_REAL, 1, temp_arr, "z", chunk);
	g_a_mass = NGA_Create(MT_REAL, 1, temp_arr, "mass", chunk);
	g_a_neigh = NGA_Create(MT_INT, 1, temp_arr, "neighbor", chunk);
	g_a_tot_mass = NGA_Create(MT_REAL, 1, temp_arr, "neighbor", chunk);
	GA_Sync();
	if(my_proc_id == 0){
		printf("# the total number of galaxies = %d\n", total_num_galaxy);
		fflush(stdout);
		printf("# ALLOCATED GA : %d %d %d %d %d %d %d\n",g_a_id, g_a_x, g_a_y, g_a_z, \
		g_a_mass, g_a_neigh, g_a_tot_mass);
		fflush(stdout);
	}

	/* Identifying ranges of array indices. */
	if (my_proc_id == 0)
	{
		printf("# Finding the array index range for galaxy data from %s\n",infn);
		fflush(stdout);
		infd=fopen(infn, "r");
		for(k=0; k < total_num_galaxy; k++) {
			// l, m, n : x, y, z axis index
			fscanf(infd, "%d %d %d %f %f %f %e", &dummy_id, &temp_int, \
			&temp_int, &dummy_x, &dummy_y, &dummy_z, &dummy_mass);
			dummy_x *= box_size;
			dummy_y *= box_size;
			dummy_z *= box_size;
			modf(dummy_x/cell_size, &temp_double);
			l = (int) temp_double;
			modf(dummy_y/cell_size, &temp_double);
			m = (int) temp_double;
			modf(dummy_z/cell_size, &temp_double);
			n = (int) temp_double;
			if(l == dim_cell) l = l - 1;
			if(m == dim_cell) m = m - 1;
			if(n == dim_cell) n = n - 1;
			// the number of galaxies that are included in the cell
			*(arr_u+n+m*dim_cell+l*(dim_cell*dim_cell)) += 1;
		}
		fclose(infd);
		// lower array bound of each cell
		prev_l = -1;
		for(l=0; l < dim_cell; l++) {
			for(m=0; m < dim_cell; m++) {
				for(n=0; n < dim_cell; n++) {
					if( (l == 0) && (m == 0) && (n == 0) ) {
						if( arr_u[0] != 0 ) {
							arr_l[0] = 0;
							prev_l = 0;
						} else {
							arr_l[0] = -1;
						}
						prev_elem = arr_u[0];
					} else {
						if( arr_u[n+m*dim_cell+l*(dim_cell*dim_cell)] > 0 ) {
							if(prev_l > -1) {
							arr_l[n+m*dim_cell+l*(dim_cell*dim_cell)] \
							= prev_l + prev_elem;
							prev_l = arr_l[n+m*dim_cell+l*(dim_cell*dim_cell)];
							} else {
							arr_l[n+m*dim_cell+l*(dim_cell*dim_cell)] = 0;
							prev_l = 0;
							}
							prev_elem = arr_u[n+m*dim_cell+l*(dim_cell*dim_cell)];
						} else {
							arr_l[n+m*dim_cell+l*(dim_cell*dim_cell)] = -1;
						}
					}
				}
			}
		}
		// upper array bound of each cell
		for(l=0; l < dim_cell; l++) {
			for(m=0; m < dim_cell; m++) {
				for(n=0; n < dim_cell; n++) {
					if(arr_l[n+m*dim_cell+l*(dim_cell*dim_cell)] > -1) {
						arr_u[n+m*dim_cell+l*(dim_cell*dim_cell)] \
						= arr_l[n+m*dim_cell+l*(dim_cell*dim_cell)] + \
						arr_u[n+m*dim_cell+l*(dim_cell*dim_cell)] - 1;
					} else {
						arr_u[n+m*dim_cell+l*(dim_cell*dim_cell)] = -1;
					}
				}
			}
		}
		if( DEBUG ) {
		for(i=0; i < dim_cell*dim_cell*dim_cell; i++) {
			printf("# %d cell statistics : particle [%d:%d]\n", i, arr_l[i], arr_u[i]);
			fflush(stdout);
			/* For the case of an incorrect calculation */
			j = arr_u[i] - arr_l[i];
			if(j < 0) {
				printf("# (ERROR) for %d cell, arr_u - arr_l = %d\n", i, j);
				fflush(stdout);
				GA_Terminate();
				MPI_Finalize();
				return 1;
			}
		}
		}
	}
	MPI_Bcast(arr_l, dim_cell*dim_cell*dim_cell, MPI_FLOAT, 0, MPI_COMM_WORLD);
	MPI_Bcast(arr_u, dim_cell*dim_cell*dim_cell, MPI_FLOAT, 0, MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);

	if (my_proc_id == 0)
	{
		ind_temp = (int *) malloc(sizeof(int)*dim_cell*dim_cell*dim_cell);
		for(i=0; i < dim_cell*dim_cell*dim_cell; i++) {
			*(ind_temp + i) = 0;
		}
		printf("# Reading galaxy data from %s\n",infn);
		fflush(stdout);
		temp_arr2[0] = 1;
		infd=fopen(infn, "r");
		for(k=0; k < total_num_galaxy; k++) {
			fscanf(infd, "%d %d %d %f %f %f %e", &dummy_id, &temp_int, \
			&temp_int, &dummy_x, &dummy_y, &dummy_z, &dummy_mass);
			dummy_x *= box_size;
			dummy_y *= box_size;
			dummy_z *= box_size;
			modf(dummy_x/cell_size, &temp_double);
			l = (int) temp_double;
			modf(dummy_y/cell_size, &temp_double);
			m = (int) temp_double;
			modf(dummy_z/cell_size, &temp_double);
			n = (int) temp_double;
			if(l == dim_cell) l = l - 1;
			if(m == dim_cell) m = m - 1;
			if(n == dim_cell) n = n - 1;
			j = arr_l[n+m*dim_cell+l*(dim_cell*dim_cell)] + \
			ind_temp[n+m*dim_cell+l*(dim_cell*dim_cell)];
			temp_arr1[0] = j;
			temp_arr[0] = dummy_id;
			float_buf1[0] = dummy_x;
			float_buf2[0] = dummy_y;
			float_buf3[0] = dummy_z;
			float_buf4[0] = dummy_mass;
			temp_arr3[0] = 0;
			GA_Init_fence();
			NGA_Put(g_a_id, temp_arr1, temp_arr1, temp_arr, temp_arr2);
			NGA_Put(g_a_x, temp_arr1, temp_arr1, float_buf1, temp_arr2);
			NGA_Put(g_a_y, temp_arr1, temp_arr1, float_buf2, temp_arr2);
			NGA_Put(g_a_z, temp_arr1, temp_arr1, float_buf3, temp_arr2);
			NGA_Put(g_a_mass, temp_arr1, temp_arr1, float_buf4, temp_arr2);
			NGA_Put(g_a_neigh, temp_arr1, temp_arr1, temp_arr3, temp_arr2);
			GA_Fence();
			ind_temp[n+m*dim_cell+l*(dim_cell*dim_cell)] += 1;
		}
		fclose(infd);
		free(ind_temp);
		printf("# Done : reading galaxy data from %s\n",infn);
		fflush(stdout);
	}
	GA_Sync();

	/* Finding the best computation approach */
	j = (dim_cell*dim_cell*dim_cell)%total_num_procs;
	i = (dim_cell*dim_cell*dim_cell - j)/total_num_procs;
	if(my_proc_id == 0) {
		printf("# (Step 1) start of searching for %d cells with %d loops\n", i*total_num_procs, i);
		fflush(stdout);
	}
	for(k = 0; k < i; k++) {
		printf("## (Step 1) %d loop on %d\n", k, my_proc_id);
		fflush(stdout);
		local_search(arr_l, arr_u, total_num_procs, my_proc_id, k, g_a_id, g_a_x, \
		g_a_y, g_a_z, g_a_mass, g_a_neigh, g_a_tot_mass);
	}
	if(my_proc_id == 0) {
		printf("# (Step 2) start of searching for %d rest cells\n", j);
		fflush(stdout);
	}
	local_search_rest(arr_l, arr_u, total_num_procs, my_proc_id, k, j, g_a_id, g_a_x, \
	g_a_y, g_a_z, g_a_mass, g_a_neigh, g_a_tot_mass);


	/* Writing results to a single file. */
	MPI_Barrier(MPI_COMM_WORLD);
	if(my_proc_id == 0) {
		printf("# Writing a result file %s.\n", outfn);
		fflush(stdout);
		write_result(outfn, g_a_id, g_a_x, g_a_y, g_a_z, g_a_mass, g_a_neigh, g_a_tot_mass, write_line, total_num_galaxy);
		printf("# Done : writing a result file %s.\n", outfn);
		fflush(stdout);
	}


	GA_Terminate();
	MPI_Finalize();
	return 0;
}
