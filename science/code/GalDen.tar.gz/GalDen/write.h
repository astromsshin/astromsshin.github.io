void write_result(const char *outfn, int g_a_id, int g_a_x, int g_a_y, int g_a_z, \
int g_a_mass, int g_a_neigh, int g_a_tot_mass, int write_line, int total_num_galaxy);
