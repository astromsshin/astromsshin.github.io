#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"
#include "global.h"
#include "ga.h"
#include "macdecls.h"
#include "search.h"


void local_search(int *arr_l, int *arr_u, int total_num_procs, int my_proc_id, int loop_num, \
int g_a_id, int g_a_x, int g_a_y, int g_a_z, int g_a_mass, int g_a_neigh, int g_a_tot_mass)
{
	int i, j, k, l, m, n, ind_r, ind_c; // x, y, and z cell indices
	int array_ind, int_tmp1, int_tmp2, int_tmp3;
	int n_member, *neigh_num;
	int lo[1], hi[1], stride[1];
	float *x_r, *y_r, *z_r, *mass_r, *x_c, *y_c, *z_c, *mass_c, *neigh_mass;
	float dist;

	array_ind = loop_num*total_num_procs + my_proc_id;
	int_tmp1 = array_ind%(dim_cell*dim_cell);
	l = (array_ind - int_tmp1)/(dim_cell*dim_cell);
	int_tmp2 = int_tmp1%dim_cell;
	m = (int_tmp1 - int_tmp2)/dim_cell;
	n = int_tmp2;

	/* reference : extracting the information for the cell(l, m, n) */
	lo[0] = *(arr_l+array_ind);
	hi[0] = *(arr_u+array_ind);
	printf("# Searching for the cell %d = l %d m %d n %d on %d with particles [%d : %d]\n", \
	array_ind, l, m, n, my_proc_id, lo[0], hi[0]);
	// checking whether the cell has any galaxies.
	if( lo[0] != -1 ) {

// if there are galaxies, the searching part starts.
	n_member = (hi[0] - lo[0]) + 1;
	stride[0] = n_member;
/*	printf("# Searching for the cell %d = l %d m %d n %d on %d with particles [%d : %d]\n", \
	array_ind, l, m, n, my_proc_id, lo[0], hi[0]); */
	fflush(stdout);
	x_r = (float *) malloc(sizeof(float)*n_member);
	y_r = (float *) malloc(sizeof(float)*n_member);
	z_r = (float *) malloc(sizeof(float)*n_member);
	mass_r = (float *) malloc(sizeof(float)*n_member);
	GA_Init_fence();
	NGA_Get(g_a_x, lo, hi, x_r, stride);
	NGA_Get(g_a_y, lo, hi, y_r, stride);
	NGA_Get(g_a_z, lo, hi, z_r, stride);
	NGA_Get(g_a_mass, lo, hi, mass_r, stride);
	GA_Fence();
	neigh_num = (int *) malloc(sizeof(int)*n_member);
	neigh_mass = (float *) malloc(sizeof(float)*n_member);

	/* searching inside the reference cell */
	// i = reference, j = comparison
	for(i=0; i < n_member; i++) {
		*(neigh_num + i) = 0;
		*(neigh_mass + i) = 0.0;
		for(j=0; j < n_member; j++) {
			if( i != j ) {
				dist = (*(x_r + i) - *(x_r + j))*(*(x_r + i) - *(x_r + j)) \
				+ (*(y_r + i) - *(y_r + j))*(*(y_r + i) - *(y_r + j)) \
				+ (*(z_r + i) - *(z_r + j))*(*(z_r + i) - *(z_r + j));
				if( dist <= search_rad_sq) {
					*(neigh_num + i) += 1;
					*(neigh_mass + i) += *(mass_r + j);
				}
			}
		}
	}

	/* searching 26 neighbor cells */
	for(i=l-1; i < (l+2); i++) {
		for(j=m-1; j < (m+2); j++) {
			for(k=n-1; k < (n+2); k++) {
				// except for itself
				if( (i != l) || (j != m) || (k != n) ) {
					switch(i) {
						case -1 :
							int_tmp1 = (dim_cell - 1)*dim_cell*dim_cell;
							break;
						case dim_cell :
							int_tmp1 = 0;
							break;
						default:
							int_tmp1 = i*dim_cell*dim_cell;
					}
					switch(j) {
						case -1 :
							int_tmp1 = int_tmp1 + (dim_cell - 1)*dim_cell;
							break;
						case dim_cell :
							break;
						default:
							int_tmp1 = int_tmp1 + j*dim_cell;
					}
					switch(k) {
						case -1 :
							int_tmp1 = int_tmp1 + (dim_cell - 1);
							break;
						case dim_cell :
							break;
						default:
							int_tmp1 = int_tmp1 + k;
					}
					/* Extractinc comparison data */
					lo[0] = *(arr_l+int_tmp1);
					hi[0] = *(arr_u+int_tmp1);
					// checking whether the comparison cell has any galaxies
					if(lo[0] != -1) {

					// if there are galaxies
					stride[0] = (hi[0] - lo[0]) + 1;
					x_c = (float *) malloc(sizeof(float)*stride[0]);
					y_c = (float *) malloc(sizeof(float)*stride[0]);
					z_c = (float *) malloc(sizeof(float)*stride[0]);
					mass_c = (float *) malloc(sizeof(float)*stride[0]);
					GA_Init_fence();
					NGA_Get(g_a_x, lo, hi, x_c, stride);
					NGA_Get(g_a_y, lo, hi, y_c, stride);
					NGA_Get(g_a_z, lo, hi, z_c, stride);
					NGA_Get(g_a_mass, lo, hi, mass_c, stride);
					GA_Fence();
					for(ind_r=0; ind_r < n_member; ind_r++) {
					for(ind_c=0; ind_c < stride[0]; ind_c++) {
					switch(i) {
						case -1 :
					dist = (*(x_r + ind_r) - *(x_c + ind_c) + box_size)*(*(x_r + ind_r) - *(x_c + ind_c) + box_size);
							break;
						case dim_cell :
					dist = (*(x_r + ind_r) - *(x_c + ind_c) - box_size)*(*(x_r + ind_r) - *(x_c + ind_c) - box_size);
							break;
						default:
					dist = (*(x_r + ind_r) - *(x_c + ind_c))*(*(x_r + ind_r) - *(x_c + ind_c));
					}
					switch(j) {
						case -1 :
					dist = dist + (*(y_r + ind_r) - *(y_c + ind_c) + box_size)*(*(y_r + ind_r) - *(y_c + ind_c) + box_size);
							break;
						case dim_cell :
					dist = dist + (*(y_r + ind_r) - *(y_c + ind_c) - box_size)*(*(y_r + ind_r) - *(y_c + ind_c) - box_size);
							break;
						default:
					dist = dist + (*(y_r + ind_r) - *(y_c + ind_c))*(*(y_r + ind_r) - *(y_c + ind_c));
					}
					switch(k) {
						case -1 :
					dist = dist + (*(z_r + ind_r) - *(z_c + ind_c) + box_size)*(*(z_r + ind_r) - *(z_c + ind_c) + box_size);
							break;
						case dim_cell :
					dist = dist + (*(z_r + ind_r) - *(z_c + ind_c) - box_size)*(*(z_r + ind_r) - *(z_c + ind_c) - box_size);
							break;
						default:
					dist = dist + (*(z_r + ind_r) - *(z_c + ind_c))*(*(z_r + ind_r) - *(z_c + ind_c));
					}
						if( dist <= search_rad_sq) {
							*(neigh_num + ind_r) += 1;
							*(neigh_mass + ind_r) += *(mass_c + ind_c);
						}
					}
					}
					free(x_c);
					free(y_c);
					free(z_c);
					free(mass_c);

					// the end of searching
					}
				}
			}
		}
	}

// the end of searching part
	}
	printf("# Done : searching for the cell l %d m %d n %d on %d\n", l, m, n, my_proc_id);
	fflush(stdout);

	/* Updating the search results */
	lo[0] = *(arr_l+array_ind);
	hi[0] = *(arr_u+array_ind);
	stride[0] = n_member;
	// checking whether the cell has any galaxies.
	if( lo[0] != -1 ) {
		GA_Init_fence();
		NGA_Put(g_a_neigh, lo, hi, neigh_num, stride);
		NGA_Put(g_a_tot_mass, lo, hi, neigh_mass, stride);
		GA_Fence();
		free(x_r);
		free(y_r);
		free(z_r);
		free(neigh_num);
		free(neigh_mass);
	}

}


void local_search_rest(int *arr_l, int *arr_u, int total_num_procs, int my_proc_id, int loop_num, \
int loop_ind, int g_a_id, int g_a_x, int g_a_y, int g_a_z, int g_a_mass, int g_a_neigh, int g_a_tot_mass)
{

	int i, j, k, l, m, n, ind_r, ind_c; // x, y, and z cell indices
	int array_ind, int_tmp1, int_tmp2, int_tmp3;
	int n_member, *neigh_num;
	int lo[1], hi[1], stride[1];
	float *x_r, *y_r, *z_r, *mass_r, *x_c, *y_c, *z_c, *mass_c, *neigh_mass;
	float dist;

	/* The search is required for only related processors. */
	if(my_proc_id < loop_ind) {

	array_ind = loop_num*total_num_procs + my_proc_id;
	int_tmp1 = array_ind%(dim_cell*dim_cell);
	l = (array_ind - int_tmp1)/(dim_cell*dim_cell);
	int_tmp2 = int_tmp1%dim_cell;
	m = (int_tmp1 - int_tmp2)/dim_cell;
	n = int_tmp2;

	/* reference : extracting the information for the cell(l, m, n) */
	lo[0] = *(arr_l+array_ind);
	hi[0] = *(arr_u+array_ind);
	printf("# Searching for the cell %d = l %d m %d n %d on %d with particles [%d : %d]\n", \
	array_ind, l, m, n, my_proc_id, lo[0], hi[0]);
	// checking whether the cell has any galaxies.
	if( lo[0] != -1 ) {

// if there are galaxies, the searching part starts.
	n_member = (hi[0] - lo[0]) + 1;
	stride[0] = n_member;
/*	printf("# Searching for the cell %d = l %d m %d n %d on %d with particles [%d : %d]\n", \
	array_ind, l, m, n, my_proc_id, lo[0], hi[0]); */
	fflush(stdout);
	x_r = (float *) malloc(sizeof(float)*n_member);
	y_r = (float *) malloc(sizeof(float)*n_member);
	z_r = (float *) malloc(sizeof(float)*n_member);
	mass_r = (float *) malloc(sizeof(float)*n_member);
	GA_Init_fence();
	NGA_Get(g_a_x, lo, hi, x_r, stride);
	NGA_Get(g_a_y, lo, hi, y_r, stride);
	NGA_Get(g_a_z, lo, hi, z_r, stride);
	NGA_Get(g_a_mass, lo, hi, mass_r, stride);
	GA_Fence();
	neigh_num = (int *) malloc(sizeof(int)*n_member);
	neigh_mass = (float *) malloc(sizeof(float)*n_member);

	/* searching inside the reference cell */
	// i = reference, j = comparison
	for(i=0; i < n_member; i++) {
		*(neigh_num + i) = 0;
		*(neigh_mass + i) = 0.0;
		for(j=0; j < n_member; j++) {
			if( i != j ) {
				dist = (*(x_r + i) - *(x_r + j))*(*(x_r + i) - *(x_r + j)) \
				+ (*(y_r + i) - *(y_r + j))*(*(y_r + i) - *(y_r + j)) \
				+ (*(z_r + i) - *(z_r + j))*(*(z_r + i) - *(z_r + j));
				if( dist <= search_rad_sq) {
					*(neigh_num + i) += 1;
					*(neigh_mass + i) += *(mass_r + j);
				}
			}
		}
	}

	/* searching 26 neighbor cells */
	for(i=l-1; i < (l+2); i++) {
		for(j=m-1; j < (m+2); j++) {
			for(k=n-1; k < (n+2); k++) {
				// except for itself
				if( (i != l) || (j != m) || (k != n) ) {
					switch(i) {
						case -1 :
							int_tmp1 = (dim_cell - 1)*dim_cell*dim_cell;
							break;
						case dim_cell :
							int_tmp1 = 0;
							break;
						default:
							int_tmp1 = i*dim_cell*dim_cell;
					}
					switch(j) {
						case -1 :
							int_tmp1 = int_tmp1 + (dim_cell - 1)*dim_cell;
							break;
						case dim_cell :
							break;
						default:
							int_tmp1 = int_tmp1 + j*dim_cell;
					}
					switch(k) {
						case -1 :
							int_tmp1 = int_tmp1 + (dim_cell - 1);
							break;
						case dim_cell :
							break;
						default:
							int_tmp1 = int_tmp1 + k;
					}
					/* Extractinc comparison data */
					lo[0] = *(arr_l+int_tmp1);
					hi[0] = *(arr_u+int_tmp1);
					// checking whether the comparison cell has any galaxies
					if(lo[0] != -1) {

					// if there are galaxies
					stride[0] = (hi[0] - lo[0]) + 1;
					x_c = (float *) malloc(sizeof(float)*stride[0]);
					y_c = (float *) malloc(sizeof(float)*stride[0]);
					z_c = (float *) malloc(sizeof(float)*stride[0]);
					mass_c = (float *) malloc(sizeof(float)*stride[0]);
					GA_Init_fence();
					NGA_Get(g_a_x, lo, hi, x_c, stride);
					NGA_Get(g_a_y, lo, hi, y_c, stride);
					NGA_Get(g_a_z, lo, hi, z_c, stride);
					NGA_Get(g_a_mass, lo, hi, mass_c, stride);
					GA_Fence();
					for(ind_r=0; ind_r < n_member; ind_r++) {
					for(ind_c=0; ind_c < stride[0]; ind_c++) {
					switch(i) {
						case -1 :
					dist = (*(x_r + ind_r) - *(x_c + ind_c) + box_size)*(*(x_r + ind_r) - *(x_c + ind_c) + box_size);
							break;
						case dim_cell :
					dist = (*(x_r + ind_r) - *(x_c + ind_c) - box_size)*(*(x_r + ind_r) - *(x_c + ind_c) - box_size);
							break;
						default:
					dist = (*(x_r + ind_r) - *(x_c + ind_c))*(*(x_r + ind_r) - *(x_c + ind_c));
					}
					switch(j) {
						case -1 :
					dist = dist + (*(y_r + ind_r) - *(y_c + ind_c) + box_size)*(*(y_r + ind_r) - *(y_c + ind_c) + box_size);
							break;
						case dim_cell :
					dist = dist + (*(y_r + ind_r) - *(y_c + ind_c) - box_size)*(*(y_r + ind_r) - *(y_c + ind_c) - box_size);
							break;
						default:
					dist = dist + (*(y_r + ind_r) - *(y_c + ind_c))*(*(y_r + ind_r) - *(y_c + ind_c));
					}
					switch(k) {
						case -1 :
					dist = dist + (*(z_r + ind_r) - *(z_c + ind_c) + box_size)*(*(z_r + ind_r) - *(z_c + ind_c) + box_size);
							break;
						case dim_cell :
					dist = dist + (*(z_r + ind_r) - *(z_c + ind_c) - box_size)*(*(z_r + ind_r) - *(z_c + ind_c) - box_size);
							break;
						default:
					dist = dist + (*(z_r + ind_r) - *(z_c + ind_c))*(*(z_r + ind_r) - *(z_c + ind_c));
					}
						if( dist <= search_rad_sq) {
							*(neigh_num + ind_r) += 1;
							*(neigh_mass + ind_r) += *(mass_c + ind_c);
						}
					}
					}
					free(x_c);
					free(y_c);
					free(z_c);
					free(mass_c);

					// the end of searching
					}
				}
			}
		}
	}

// the end of searching part
	}
	printf("# Done : searching for the cell l %d m %d n %d on %d\n", l, m, n, my_proc_id);
	fflush(stdout);

	/* Updating the search results */
	lo[0] = *(arr_l+array_ind);
	hi[0] = *(arr_u+array_ind);
	stride[0] = n_member;
	// checking whether the cell has any galaxies.
	if( lo[0] != -1 ) {
		GA_Init_fence();
		NGA_Put(g_a_neigh, lo, hi, neigh_num, stride);
		NGA_Put(g_a_tot_mass, lo, hi, neigh_mass, stride);
		GA_Fence();
		free(x_r);
		free(y_r);
		free(z_r);
		free(neigh_num);
		free(neigh_mass);
	}

	}

}
