#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"
#include "global.h"
#include "ga.h"
#include "macdecls.h"
#include "search.h"
#include "write.h"

void write_result(const char *outfn, int g_a_id, int g_a_x, int g_a_y, int g_a_z, \
int g_a_mass, int g_a_neigh, int g_a_tot_mass, int write_line, int total_num_galaxy)
{

	FILE* outfd;
	int loop_num, rest_num, i, j;
	int id[write_line], neigh[write_line];
	float x[write_line], y[write_line], z[write_line];
	float mass[write_line], tot_mass[write_line];
	int lo[1], hi[1], stride[1];

	outfd = fopen(outfn, "w");
	rest_num = total_num_galaxy%write_line;
	loop_num = (total_num_galaxy - rest_num)/write_line;
	fprintf(outfd, "# search radius = %f for %d galaxies\n", search_rad, total_num_galaxy);
	// loop
	stride[0] = write_line;
	for(i=0; i < loop_num; i++) {
		lo[0] = i*write_line;
		hi[0] = (i+1)*write_line - 1;
		GA_Init_fence();
		NGA_Get(g_a_id, lo, hi, id, stride);
		NGA_Get(g_a_x, lo, hi, x, stride);
		NGA_Get(g_a_y, lo, hi, y, stride);
		NGA_Get(g_a_z, lo, hi, z, stride);
		NGA_Get(g_a_mass, lo, hi, mass, stride);
		NGA_Get(g_a_neigh, lo, hi, neigh, stride);
		NGA_Get(g_a_tot_mass, lo, hi, tot_mass, stride);
		GA_Fence();
		for(j=0; j < write_line; j++) {
			fprintf(outfd, "%d %f %f %f %e %d %e\n", id[j], \
			x[j], y[j], z[j], mass[j], neigh[j], tot_mass[j]);
		}
	}
	// rest
	lo[0] = i*write_line;
	hi[0] = lo[0] + rest_num - 1;
	stride[0] = rest_num;
	GA_Init_fence();
	NGA_Get(g_a_id, lo, hi, id, stride);
	NGA_Get(g_a_x, lo, hi, x, stride);
	NGA_Get(g_a_y, lo, hi, y, stride);
	NGA_Get(g_a_z, lo, hi, z, stride);
	NGA_Get(g_a_mass, lo, hi, mass, stride);
	NGA_Get(g_a_neigh, lo, hi, neigh, stride);
	NGA_Get(g_a_tot_mass, lo, hi, tot_mass, stride);
	GA_Fence();
	for(j=0; j < rest_num; j++) {
		fprintf(outfd, "%d %f %f %f %e %d %e\n", id[j], \
		x[j], y[j], z[j], mass[j], neigh[j], tot_mass[j]);
	}
	fclose(outfd);

}
