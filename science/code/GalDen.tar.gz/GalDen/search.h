#define search_rad 8.0
#define search_rad_sq 64.0
#define box_size 85.0
#define dim_cell 10
#define cell_size 8.50 // The cell_size must be larger than the search radius.

void local_search(int *arr_l, int *arr_u, int total_num_procs, int my_proc_id, int loop_num, \
int g_a_id, int g_a_x, int g_a_y, int g_a_z, int g_a_mass, int g_a_neigh, int g_a_tot_mass);


void local_search_rest(int *arr_l, int *arr_u, int total_num_procs, int my_proc_id, int loop_num, \
int loop_ind, int g_a_id, int g_a_x, int g_a_y, int g_a_z, int g_a_mass, int g_a_neigh, \
int g_a_tot_mass);
