#!/bin/bash

./SLLK_est.exe test_sine 6002
./minmax.exe test_sine.length.pdg -p -M -w 3 | sort -k2 -g > test_sine.length.pdg.peak
