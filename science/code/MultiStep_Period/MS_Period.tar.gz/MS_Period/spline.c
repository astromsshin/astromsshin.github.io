#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<spline_inc.h>

#ifdef _OPENMP
#include <omp.h>
#endif

#define DEFAULT_dP_plus_P_over_P 1.00001

void usage_option(void)
{
        printf("Required command-line inputs:\n");
        printf("  [3 cols data file name] [number of rows] [number of candidate periods]\n");
        printf("Optional command-line inputs:\n");
        printf(" -s<value> trial period step-size\n");
        printf("           Negative values mean deltaP = a given constant (e.x. -s-0.01).\n");
        printf("           Positive values mean deltaP/P = a given constant (e.x. -s0.01).\n");
        printf("           The default value is deltaP/P = %f.\n", (DEFAULT_dP_plus_P_over_P - 1.0));
}

int parse_option(int argc, char *argv[], int *opt_tag, double *opt_value)
{
        while(argc > 1) {
                if(argv[argc-1][0] == '-') {
                        switch (argv[argc-1][1])
                        {
                                case 's':
                                        *opt_value = atof(&argv[argc-1][2]);
                                        if(*opt_value > 0) {
                                                *opt_tag = 1;
                                        } else {
                                                *opt_tag = -1;
                                        }
                                        break;
                                default:
                                        printf("Wrong arguments %s.\n", argv[argc-1]);
                                        return 1;       
                        }
                }
                argc = argc - 1;
        }
	return 0;
}

double cal(double *date_array, double *mag_array, double *error_array, int total_number, double trial_period);

void fit_curve(double *date_array, double *mag_array, double *error_array, int total_number, double trial_period);

int compare(const double * data1, const double * data2);

int main(int argc, char **argv)
{
	int total_number, id_n, i, j;
	FILE *input;
	double *date_array, *mag_array, *error_array;
	double can_period, max_can_period, min_can_period;
	double solution_period, solution_chi;
	static double trial_period;
	double F,temp;
	static double period, chi;
	int num_can_period;
	char chi2filename[256];
	FILE *chi2fd;
	int chi2fid = 0;
	int opt_tag=0;
	double opt_value;

#ifdef _OPENMP
        int num_cpus, num_loop, thread_id;
        double *P_array, *chi_array;
        num_cpus = omp_get_num_procs();
        printf("# OpenMP is working with %d CPUs\n", num_cpus);
        omp_set_num_threads(num_cpus);
#else
        printf("# Serial processing\n");
#endif

	if((argc != 4) && (argc != 5))
	{
		usage_option();
		return 1;
	}

	total_number = atoi(argv[2]);
	num_can_period = atoi(argv[3]);

        if( parse_option(argc, argv, &opt_tag, &opt_value) != 0 ) {
                usage_option();
                return 1;
        }
	if(opt_tag < 0) { // constant step size
		opt_value = fabs(opt_value);
	}
	if(opt_tag > 0) { // constant step size
		opt_value = opt_value + 1.0;
	}

	/* Read data file with three cols: date, mag., and mag. error */
	date_array = calloc(total_number, sizeof(double));
	mag_array = calloc(total_number, sizeof(double));
	error_array = calloc(total_number, sizeof(double));
	input = fopen(argv[1], "r");
	for(id_n = 0; id_n < total_number; ++id_n) {
			fscanf(input,"%lf %lf %lf",(date_array+id_n),(mag_array+id_n),(error_array+id_n));
			if ( *(error_array+id_n) == 0.0 ) {
				*(error_array+id_n) = 0.0004;
			}
	}
	fclose(input);
	for(id_n = 0; id_n < total_number; ++id_n) {
			*(date_array + id_n) = (*(date_array+id_n)) - (*(date_array));
	}

	/* loop to read candidate periods */	
	for(j=0; j < num_can_period; j++) {
	
	printf("# min. range of the candidate period = ");
	scanf("%lf", &min_can_period);
	printf("# the candidate period = ");
	scanf("%lf", &can_period);
	printf("# max. range of the candidate period = ");
	scanf("%lf", &max_can_period);
	printf("# the name of chi^2 file = ");
	scanf("%s", chi2filename);

	if( strcmp(chi2filename, "?") ) {
		chi2fid = 1;
		chi2fd = fopen(chi2filename, "a");
		fprintf(chi2fd, "# %f\n", can_period);
	}

	/* The range of trial periods */
	#ifdef _OPENMP
	num_loop = 0;
	trial_period = min_can_period;
	while( trial_period < max_can_period ) {
		num_loop += 1;
		if(opt_tag == 0) {
			trial_period = trial_period * DEFAULT_dP_plus_P_over_P;
		} else {
			if(opt_tag == 1) {
				trial_period = trial_period * opt_value;
			} else {
				trial_period = trial_period + opt_value;
			}
		}
	}
	P_array = calloc(num_loop, sizeof(double));
	chi_array = calloc(num_loop, sizeof(double));
	trial_period = min_can_period;
	for(i=0; i < num_loop; i++) {
		*(P_array + i) = trial_period;
		if(opt_tag == 0) {
			trial_period = trial_period * DEFAULT_dP_plus_P_over_P;
		} else {
			if(opt_tag == 1) {
				trial_period = trial_period * opt_value;
			} else {
				trial_period = trial_period + opt_value;
			}
		}
	}
	#endif
	solution_period = -1.0;
	solution_chi = -1.0;
	#ifdef _OPENMP
#pragma omp parallel default(shared)
#pragma omp for schedule(dynamic) private(trial_period,id_n,chi)
	for(id_n=0; id_n < num_loop; id_n++) {
		trial_period = *(P_array+id_n);
		chi = cal(date_array, mag_array, error_array, total_number, trial_period);
		*(chi_array+id_n) = chi;
//		printf("... %f %f\n", trial_period, chi);
	}

	for(id_n=0; id_n < num_loop; id_n++) {
		if( *(chi_array + id_n)  >= 0.0 ) {
			if( solution_chi < 0.0 ) {
				solution_chi = *(chi_array + id_n);
				solution_period = *(P_array + id_n);
			} else {
				if( solution_chi > *(chi_array + id_n) ) {
					solution_chi = *(chi_array + id_n);
					solution_period = *(P_array + id_n);
				}
			}
		}
	}
	if( chi2fid == 1 ) {
		for(id_n=0; id_n < num_loop; id_n++) {
			fprintf(chi2fd, "%f %f\n", *(P_array + id_n), *(chi_array + id_n));
		}
	}
	#else
	trial_period = min_can_period;
	while(trial_period < max_can_period) {
		chi = cal(date_array, mag_array, error_array, total_number, trial_period);
		if( chi2fid == 1 ) {
			fprintf(chi2fd, "%f %f\n", trial_period, chi);
		}
//		printf("... %.6f %f\n", trial_period, chi);
		if( chi >= 0.0 ) {
			if( solution_chi < 0.0 ) {
				solution_chi = chi;
				solution_period = trial_period;
			} else {
				if( solution_chi > chi ) {
					solution_chi = chi;
					solution_period = trial_period;
				}
			}
		}
		if(opt_tag == 0) {
			trial_period = trial_period * DEFAULT_dP_plus_P_over_P;
		} else {
			if(opt_tag == 1) {
				trial_period = trial_period * opt_value;
			} else {
				trial_period = trial_period + opt_value;
			}
		}
	}
	#endif
	if( solution_period < 0.0 ) {
		printf("%.6f N N\n", can_period);
	} else {
		printf("%.6f %.6f %.6f\n", can_period, solution_period, solution_chi);
	}

	#ifdef _OPENMP
	free(P_array);
	free(chi_array);
	#endif
/*	fit_curve(date_array, mag_array, error_array, total_number, period); */

	}
	
	free (date_array);
	free (mag_array);
	free (error_array);

	if( chi2fid == 1 ) {
		fclose(chi2fd);
	}
	
	return 0;
}

double cal(double *date_array, double *mag_array, double *error_array, int total_number, double trial_period)
{
	int n;
	double *data;
	double *phase, *phase_mag, *phase_error;
	double temp1, *temp2;
	double F;
	struct spline_dstr s;

	data = calloc((total_number*3), sizeof(double));

	phase = calloc(total_number, sizeof(double));
	phase_mag = calloc(total_number, sizeof(double));
	phase_error = calloc(total_number, sizeof(double));

	for(n=0; n < total_number; n++)
	{
			temp1 = fmod(((*(date_array+n)) - (*(date_array))), trial_period);
			*(data+n*3) = (temp1 / trial_period);
			(*(data+(n*3+1))) = (*(mag_array+n));
			(*(data+(n*3+2))) = (*(error_array+n));
	}

	qsort(data, total_number, 3*sizeof(double), compare);

	F = 0.0;
	
	for(n=0; n < total_number; n++)
	{
			(*(phase+n)) = (*(data+(n*3)));
			(*(phase_mag+n)) = (*(data+(n*3+1)));
			(*(phase_error+n)) = (*(data+(n*3+2)));
	}
	
	free(data);
	
	n = total_number * 2;
	s = spline_dicy(((total_number - 1) / 3), total_number, phase, phase_mag, phase_error, n);
	F = spline_dpls(&s);
	
//	printf("%f\n", (s.chisq));
	
	free(phase);
	free(phase_mag);
	free(phase_error);

	F = s.chisq;

	spline_dend(&s);
	
	return F;

}

void fit_curve(double *date_array, double *mag_array, double *error_array, int total_number, double trial_period)
{
	int n;
	double *data;
	double *phase, *phase_mag, *phase_error;
	double temp1, *temp2;
	double F;
	struct spline_dstr s;
	
	data = calloc((total_number*3), sizeof(double));
	phase = calloc(total_number, sizeof(double));
	phase_mag = calloc(total_number, sizeof(double));
	phase_error = calloc(total_number, sizeof(double));

	for(n=0; n < total_number; n++)
	{
			temp1 = fmod(((*(date_array+n)) - (*(date_array))), trial_period);
			*(data+n*3) = (temp1 / trial_period);
			(*(data+(n*3+1))) = (*(mag_array+n));
			(*(data+(n*3+2))) = (*(error_array+n));
	}

	qsort(data, total_number, 3*sizeof(double), compare);

	F = 0.0;
	
	for(n=0; n < total_number; n++)
	{
			(*(phase+n)) = (*(data+(n*3)));
			(*(phase_mag+n)) = (*(data+(n*3+1)));
			(*(phase_error+n)) = (*(data+(n*3+2)));
	}
	free(data);
	
	n = total_number * 2;
	s = spline_dicy(((total_number - 1) / 3), total_number, phase, phase_mag, phase_error, n);

	for( temp1 = 0.0; temp1 <= 1.0; temp1 = temp1+0.001)
	{
		F = spline_dpls(&s);
		printf("%f %f\n", temp1, spline_dval(temp1, &s) );
	}

	free(phase);
	free(phase_mag);
	free(phase_error);
	
}
		
	

int compare(const double *data1, const double *data2)
{
		if ( (*data1) < (*data2) )
		{
				return -1;
		}
		else if ( (*data1) == (*data2) )
		{
				return 0;
		}
		else
		{
				return 1;
		}
}
		
