#! /usr/bin/env python

import sys
import commands

range_factor = 0.0005

if (len(sys.argv) == 5):
	filename = sys.argv[1]
	total_number = sys.argv[2]
	can_period = float(sys.argv[3])
	min_period = can_period - can_period * range_factor;
	max_period = can_period + can_period * range_factor;
	spline_pdg_output = sys.argv[4]
	cmd_string = "echo "+str(min_period)+" "+sys.argv[3]+" "+str(max_period)+" "+spline_pdg_output+" | ./spline "+filename+" "+total_number+" 1"
	print commands.getoutput(cmd_string)
else:
	print "spline.py [time series data file] [# of rows] [candidate period] [output filename]"
