#!/usr/bin/env python

import os
import read_plot_sample
import read_plot_resample

if os.path.isfile("184010-0047.multi.pdg"):
	read_plot_sample.plot_periodogram("184010-0047.multi.pdg", save_tag=True, save_figfn="periodogram_multi.png")
	if os.path.isfile("184010-0047.multi.sample.h5"):
		read_plot_resample.plot_sample_stat_2d(0.1, 430, "184010-0047.multi.pdg", "184010-0047.multi.sample.h5", \
		save_tag=True, save_figfn="sample_stat_2d_multi.png")
		read_plot_resample.plot_sample_stat_hist(0.435801, "184010-0047.multi.pdg", "184010-0047.multi.sample.h5", \
		nbin=50, save_tag=True, save_figfn="sample_stat_hist_multi.png")
		read_plot_resample.plot_sample_jackknife_mean("184010-0047.multi.pdg", "184010-0047.multi.sample.h5", \
		save_tag=True, save_figfn="sample_jackknife_mean_multi.png")

if os.path.isfile("184010-0047.phase.pdg"):
	read_plot_sample.plot_periodogram("184010-0047.phase.pdg", save_tag=True, save_figfn="periodogram_phase.png")
	if os.path.isfile("184010-0047.phase.sample.h5"):
		read_plot_resample.plot_sample_stat_2d(0.1, 430, "184010-0047.phase.pdg", "184010-0047.phase.sample.h5", \
		save_tag=True, save_figfn="sample_stat_2d_phase.png")
		read_plot_resample.plot_sample_stat_hist(0.435801, "184010-0047.phase.pdg", "184010-0047.phase.sample.h5", \
		nbin=50, save_tag=True, save_figfn="sample_stat_hist_phase.png")
		read_plot_resample.plot_sample_jackknife_mean("184010-0047.phase.pdg", "184010-0047.phase.sample.h5", \
		save_tag=True, save_figfn="sample_jackknife_mean_phase.png")

read_plot_sample.plot_lc_phase("184010-0047", 0.435801, plot_err=True, save_tag=True, save_figfn="lc_phase.png")
read_plot_sample.plot_lc_phase_custom("184010-0047", 0.435801, "184010-0047.fold.model", plot_err=True, save_tag=True, save_figfn="lc_phase_custom.png")
read_plot_sample.plot_lc("184010-0047", plot_err=True, save_tag=True, save_figfn="lc.png")
