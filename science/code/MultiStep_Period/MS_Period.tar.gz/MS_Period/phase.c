#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#ifdef USE_ERR
#include<gsl/gsl_statistics_long_double.h>
#endif

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef USE_RESAMPLE
#include <hdf5.h>
#include <hdf5_hl.h>
#endif

#include "common.h"

#ifdef USE_ERR
long double cal_amplitude(long double *date_array, long double *mag_array, long double *error_array, \
int total_number, long double trial_freq, long double mean_mag);
#else
long double cal_amplitude(long double *date_array, long double *mag_array, int total_number, long double trial_freq, long double mean_mag);
#endif

#ifdef USE_RESAMPLE
int jackknife_sample(long double *date_array, long double *mag_array, long double *error_array, int total_number, int out_ind, long double *jackknife_date_array, long double *jackknife_mag_array, long double *jackknife_error_array, long double *new_mean_mag);
#endif

int compare(const long double * data1, const long double * data2);

int main(int argc, char **argv)
{
	int total_number, id_n, num_loop, i;
	FILE *input, *output;
	char *result_file=".phase.pdg";
	long double *date_array, *mag_array, *error_array;
	long double min_freq,max_freq,trial_freq,freq_interval;
#ifdef USE_RESAMPLE
        int total_number_minus_1;
        char hdf5_resample_file[256];
        char hdf5_dset_name[256];
        hid_t hdf5_file_id;
        hsize_t hdf5_dims[1];
        herr_t hdf5_status;
        long double *sample_date_array, *sample_mag_array, *sample_error_array;
        double *F_sample_array;
        long double sample_mean_mag;
#endif
	long double mean_mag,temp,temp_freq,F;
	long double min_period_factor=1.00, max_period_factor=1.00;
	int opt_tag[5] = {0, 0, 0, 0, 0};
	long double opt_value[5];

#ifdef _OPENMP
        int num_cpus;
        long double *P_array;
        long double *f_array;
        long double *F_array;
        num_cpus = omp_get_num_procs();
        printf("# OpenMP is working with %d CPUs\n", num_cpus);
        omp_set_num_threads(num_cpus);
#endif

	if(argc < 3)
	{
		usage_option();
		return 1;
	}

	total_number = atoi(argv[2]);
	#ifdef USE_RESAMPLE
        total_number_minus_1 = total_number - 1;
        #endif

	date_array = calloc(total_number, sizeof(long double));
	if(date_array == NULL) {fprintf(stderr, "Memory problem: date_array\n"); return 1;}
	mag_array = calloc(total_number, sizeof(long double));
	if(mag_array == NULL) {fprintf(stderr, "Memory problem: mag_array\n"); return 1;}
	error_array = calloc(total_number, sizeof(long double));
	if(error_array == NULL) {fprintf(stderr, "Memory problem: error_array\n"); return 1;}

        if( parse_option(argc, argv, &opt_tag[0], &opt_value[0]) != 0 ) {
                usage_option();
                return 1;
        }
        if( opt_tag[3] != 0 ) {
                min_period_factor = opt_value[3];
        }
        if( opt_tag[4] != 0 ) {
                max_period_factor = opt_value[4];
        }

	input = fopen(argv[1], "r");
        #ifdef USE_RESAMPLE
        sprintf(hdf5_resample_file, "%s.phase.sample.h5", argv[1]);
        #endif
	result_file = strcat(argv[1],result_file);

	
/* Read data file with three cols: date, mag., and mag. error */
	
	for(id_n = 0; id_n < total_number; ++id_n) {
			fscanf(input,"%Lf %Lf %Lf",(date_array+id_n),(mag_array+id_n),(error_array+id_n));
#ifdef USE_ERR
                        if((*(error_array+id_n)) == 0.0)
                        {
                                (*(error_array+id_n)) = 0.0004;
                        }
                        *(error_array + id_n) = 1.0 / ((*(error_array+id_n)) * (*(error_array+id_n)));
#endif
	}

#ifdef USE_ERR
	mean_mag = gsl_stats_long_double_wmean(error_array, 1, mag_array, 1, total_number);
#else
	mean_mag = 0.0;
	for(id_n = 0; id_n < total_number; ++id_n) {
			mean_mag = mean_mag + *(mag_array + id_n);
	}
	mean_mag = mean_mag / total_number;
#endif

/* Trial frequency setting */

	temp = (*(date_array+total_number-1)) - (*date_array);
	min_freq = 2.0 * M_PI / temp;
	max_freq = min_freq;
	for(id_n = 0; id_n < (total_number-1); ++id_n) {
			temp_freq = M_PI / (*(date_array+id_n+1) - *(date_array+id_n));
			if( temp_freq > max_freq ) {
				max_freq = temp_freq;
			}
	}
	if( max_freq > (2.0 * M_PI / 0.000001) )
	{
		max_freq = (2.0 * M_PI / 0.000001);
	}

	printf("# Min f. %Lf Max f. %Lf Min P. %Lf Max P. %Lf\n", min_freq, max_freq, (2.0 * M_PI / max_freq), (2.0 * M_PI / min_freq));

	/* User-given limits */
        if(opt_tag[0] != 0) { // minimum period
                max_freq = (2.0 * M_PI / opt_value[0]);
        }
        if(opt_tag[1] != 0) { // maximum period
                min_freq = (2.0 * M_PI / opt_value[1]);
        }
        if( opt_tag[3] != 0 ) {
                max_freq = max_freq / min_period_factor;
        }
        if( opt_tag[4] != 0 ) {
                min_freq = min_freq / max_period_factor;
        }
        if( (opt_tag[0] != 0) || (opt_tag[1] != 0) || (opt_tag[3] != 0) || (opt_tag[4] != 0) ) {
                printf("... using Min f. %Lf Max f. %Lf Min P. %Lf Max P. %Lf\n",min_freq,max_freq,(2.0 * M_PI / max_freq),(2.0 * M_PI / min_freq));
        }
        if(opt_tag[2] == 0) {
                opt_value[2] = DEFAULT_dP_over_P;
        }
        if(opt_tag[2] == -1) { // constant step size
                opt_value[2] = fabsl(opt_value[2]);
        }
        /* Validation of trial periods range */
        if(max_freq < min_freq) {
                printf("... the period range does not work.\n");
                usage_option();
                return 1;
        }

	output = fopen(result_file, "w");

	trial_freq = min_freq;
        #ifdef _OPENMP // OpenMP parallelization.
	num_loop = 0;
        while (trial_freq <= max_freq) {
                        num_loop += 1;
                        if(opt_tag[2] < 0) { // dP = constant.
                                freq_interval = trial_freq * trial_freq * opt_value[2] * 0.50 * M_1_PI;
                        } else { // dP/P = constant.
                                freq_interval = trial_freq * opt_value[2];
                        }
                        trial_freq = trial_freq + freq_interval;
        }
        P_array = calloc(num_loop, sizeof(long double));
        if(P_array == NULL) {fprintf(stderr, "Memory problem: P_array\n"); return 1;}
        f_array = calloc(num_loop, sizeof(long double));
        if(f_array == NULL) {fprintf(stderr, "Memory problem: f_array\n"); return 1;}
        F_array = calloc(num_loop, sizeof(long double));
        if(F_array == NULL) {fprintf(stderr, "Memory problem: F_array\n"); return 1;}
        trial_freq = min_freq;
        for(i=0; i < num_loop; i++) {
                        *(P_array + i) = (2.0 * M_PI) / trial_freq;
                        *(f_array + i) = trial_freq;
                        if(opt_tag[2] < 0) { // dP = constant.
                                freq_interval = trial_freq * trial_freq * opt_value[2] * 0.50 * M_1_PI;
                        } else { // dP/P = constant.
                                freq_interval = trial_freq * opt_value[2];
                        }
                        trial_freq = trial_freq + freq_interval;
        }
	#else // OpenMP parallelization.
	#ifdef USE_RESAMPLE
        num_loop = 0;
        while (trial_freq <= max_freq) {
                        num_loop += 1;
                        if(opt_tag[2] < 0) { // dP = constant.
                                freq_interval = trial_freq * trial_freq * opt_value[2] * 0.50 * M_1_PI;
                        } else { // dP/P = constant.
                                freq_interval = trial_freq * opt_value[2];
                        }
                        trial_freq = trial_freq + freq_interval;
        }
	#endif
	#endif // OpenMP parallelization.
	#ifdef USE_RESAMPLE
	hdf5_dims[0] = num_loop;
        F_sample_array = calloc(num_loop, sizeof(double));
        if(F_sample_array == NULL) {fprintf(stderr, "Memory problem: F_sample_array\n"); return 1;}
        hdf5_file_id = H5Fcreate(hdf5_resample_file, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);
	#endif

	#ifdef _OPENMP // OpenMP parallelization.
	// Estimation by using the original data.
#pragma omp parallel default(shared)
#pragma omp for schedule(dynamic) private(id_n,F,trial_freq)
	for(id_n=0; id_n < num_loop; id_n++) {
			trial_freq = *(f_array + id_n);
#ifdef USE_ERR
			F = cal_amplitude(date_array, mag_array, error_array, total_number, trial_freq, mean_mag);
#else
			F = cal_amplitude(date_array, mag_array, total_number, trial_freq, mean_mag);
#endif
			*(F_array + id_n) = F;
	}
        #ifdef USE_RESAMPLE // Resampling starts when OpenMP is on.
        sample_date_array = calloc(total_number_minus_1, sizeof(long double));
        if(sample_date_array == NULL) {fprintf(stderr, "Memory problem: sample_date_array\n"); return 1;}
        sample_mag_array = calloc(total_number_minus_1, sizeof(long double));
        if(sample_mag_array == NULL) {fprintf(stderr, "Memory problem: sample_mag_array\n"); return 1;}
        sample_error_array = calloc(total_number_minus_1, sizeof(long double));
        if(sample_error_array == NULL) {fprintf(stderr, "Memory problem: sample_error_array\n"); return 1;}
	for(i=0; i < total_number; ++i) {
		jackknife_sample(date_array, mag_array, error_array, total_number, i, \
		sample_date_array, sample_mag_array, sample_error_array, &sample_mean_mag);
#pragma omp parallel default(shared)
#pragma omp for schedule(dynamic) private(id_n,F,trial_freq)
		for(id_n=0; id_n < num_loop; id_n++) {
			trial_freq = *(f_array + id_n);
#ifdef USE_ERR
			F = cal_amplitude(sample_date_array, sample_mag_array, sample_error_array, total_number_minus_1, \
			trial_freq, sample_mean_mag);
#else
			F = cal_amplitude(sample_date_array, sample_mag_array, total_number_minus_1, trial_freq, sample_mean_mag);
#endif
			*(F_sample_array + id_n) = F; // Jackknife replication.
		}
		sprintf(hdf5_dset_name, "/sample%d", i+1);
		hdf5_status = H5LTmake_dataset(hdf5_file_id, hdf5_dset_name, 1, hdf5_dims, H5T_NATIVE_DOUBLE, F_sample_array);
	}
        free(sample_date_array);
        free(sample_mag_array);
        free(sample_error_array);
        #endif // Resampling starts when OpenMP is on.
	#else // OpenMP parallelization.
	// Estimation by using the original data.
	trial_freq = min_freq;
	while (trial_freq <= max_freq) {
#ifdef USE_ERR
			F = cal_amplitude(date_array, mag_array, error_array, total_number, trial_freq, mean_mag);
#else
			F = cal_amplitude(date_array, mag_array, total_number, trial_freq, mean_mag);
#endif
			temp = (2.0 * M_PI) / trial_freq;
			fprintf(output,"%.6Lf %.6Lf\n",temp, F);
                        if(opt_tag[2] < 0) { // dP = constant.
                                freq_interval = trial_freq * trial_freq * opt_value[2] * 0.50 * M_1_PI;
                        } else { // dP/P = constant.
                                freq_interval = trial_freq * opt_value[2];
                        }
			trial_freq = trial_freq + freq_interval;
	}
        #ifdef USE_RESAMPLE // Resampling starts when OpenMP is off.
        sample_date_array = calloc(total_number_minus_1, sizeof(long double));
        if(sample_date_array == NULL) {fprintf(stderr, "Memory problem: sample_date_array\n"); return 1;}
        sample_mag_array = calloc(total_number_minus_1, sizeof(long double));
        if(sample_mag_array == NULL) {fprintf(stderr, "Memory problem: sample_mag_array\n"); return 1;}
        sample_error_array = calloc(total_number_minus_1, sizeof(long double));
        if(sample_error_array == NULL) {fprintf(stderr, "Memory problem: sample_error_array\n"); return 1;}
	for(i=0; i < total_number; ++i) {
		jackknife_sample(date_array, mag_array, error_array, total_number, i, \
		sample_date_array, sample_mag_array, sample_error_array, &sample_mean_mag);
		trial_freq = min_freq;
		id_n = 0;
		while (trial_freq <= max_freq) {
#ifdef USE_ERR
			F = cal_amplitude(sample_date_array, sample_mag_array, sample_error_array, total_number_minus_1, \
			trial_freq, sample_mean_mag);
#else
			F = cal_amplitude(sample_date_array, sample_mag_array, total_number_minus_1, trial_freq, sample_mean_mag);
#endif
			*(F_sample_array + id_n) = F; // Jackknife replication.
                        if(opt_tag[2] < 0) { // dP = constant.
                                freq_interval = trial_freq * trial_freq * opt_value[2] * 0.50 * M_1_PI;
                        } else { // dP/P = constant.
                                freq_interval = trial_freq * opt_value[2];
                        }
			trial_freq = trial_freq + freq_interval;
			id_n = id_n + 1;
		}
		sprintf(hdf5_dset_name, "/sample%d", i+1);
		hdf5_status = H5LTmake_dataset(hdf5_file_id, hdf5_dset_name, 1, hdf5_dims, H5T_NATIVE_DOUBLE, F_sample_array);
	}
        free(sample_date_array);
        free(sample_mag_array);
        free(sample_error_array);
        #endif // Resampling starts when OpenMP is off.
	#endif // OpenMP parallelization
#ifdef _OPENMP
        for(id_n=0; id_n < num_loop; id_n++) {
                fprintf(output,"%.6Lf %.6Lf\n",*(P_array + id_n), *(F_array + id_n));
        }
        free (P_array);
        free (f_array);
        free (F_array);
#endif
					
	fclose(input);
	fclose(output);

	free (date_array);
	free (mag_array);
	free (error_array);

        #ifdef USE_RESAMPLE
        hdf5_status = H5Fclose(hdf5_file_id);
        #endif
	
	return 0;
}

#ifdef USE_ERR
long double cal_amplitude(long double *date_array, long double *norm_mag, long double *error_array, int total_number, long double trial_freq, long double mean_mag)
{
        long double *data, *bin_mean;
        int n, id, nbin, temp_bin, num_rest, num_per_bin;
        long double temp1, s1, s2, bin_s;
        double temp, temp2;
        long double use_error, error_sum;

        nbin = USE_NBIN;
        /* the code actually uses nbin + 1 bins when there are extra data points.
           see the num_rest value. */

        data = calloc((total_number*3), sizeof(long double));
	if(data == NULL) {fprintf(stderr, "Memory problem: data\n"); return 1;}

        for(n=0; n < total_number; n++)
        {
                        (*(data+(n*3+1))) = (*(norm_mag+n));
                        (*(data+(n*3+2))) = (*(error_array+n));
        }
        for(n=0; n < total_number; n++)
        {
                        temp1 = ((*(date_array+n)) - (*(date_array))) * trial_freq / (2.0 * M_PI);
                        *(data+n*3) = modf(temp1, &temp2);
        }
        qsort(data, total_number, 3*sizeof(long double), compare);

        temp = modf((total_number / nbin), &temp2);
        num_per_bin = (int) temp2;
        temp1 = total_number - nbin * temp2;
        num_rest = (int) temp1;
        /* num_per_bin, i.e. temp2 = the number of data points in the bin */
        /* num_rest, i.e. temp1 = the rest of data points */
        if(num_rest > 0) {
                bin_mean = calloc((nbin+1), sizeof(long double));
        } else {
                bin_mean = calloc(nbin, sizeof(long double));
        }

        /* s_1^2 */
        s1 = 0.0;
        for(n=0; n < nbin; n++)
        {
                temp = 0.0;
                error_sum = 0.0;
                for(id=0; id < num_per_bin; id++)
                {
                        temp_bin = n * num_per_bin + id;
                        use_error = *(data+(temp_bin*3+2));
                        error_sum = error_sum + use_error;
                        temp = temp + use_error * (*(data+(temp_bin*3+1)));
                }
                *(bin_mean+n) = temp / error_sum;
                s1 = s1 + temp2 * ( (*(bin_mean+n)) - mean_mag) * ( (*(bin_mean+n)) - mean_mag);
        }
        if( num_rest != 0 )
        {
                temp = 0.0;
                error_sum = 0.0;
                for(id=0; id < num_rest; id++)
                {
                        temp_bin = nbin * num_per_bin + id;
                        use_error = *(data+(temp_bin*3+2));
                        error_sum = error_sum + use_error;
                        temp = temp + use_error * (*(data+(temp_bin*3+1)));
                }
                *(bin_mean+nbin) = temp / error_sum;
                s1 = s1 + temp1 * ( (*(bin_mean+nbin)) - mean_mag) * ( (*(bin_mean+nbin)) - mean_mag);
        }
        if( num_rest == 0) {
                s1 = s1 / (nbin - 1);
        } else {
                s1 = s1 / nbin;
        }
        

        /* s_2^2 */
        s2 = 0.0;
        for(n=0; n < nbin; n++)
        {
                for(id=0; id < num_per_bin; id++)
                {
                        temp_bin = n * num_per_bin + id;
                        bin_s = *(data+(temp_bin*3+1)) - *(bin_mean+n);
                        s2 = s2 + bin_s * bin_s;
                }
        }
        if( num_rest != 0 )
        {
                for(id=0; id < num_rest; id++)
                {
                        temp_bin = nbin * num_per_bin + id;
                        bin_s = *(data+(temp_bin*3+1)) - *(bin_mean+nbin);
                        s2 = s2 + bin_s * bin_s;
                }
        }
        if( num_rest == 0) {
                s2 = s2 / (total_number - nbin);
        } else {
                s2 = s2 / (total_number - nbin - 1);
        }

        free(bin_mean);
        free(data);
        
        return ( s1 / s2 );
}
#else
long double cal_amplitude(long double *date_array, long double *norm_mag, int total_number, long double trial_freq, long double mean_mag)
{
	long double *data, *bin_mean;
	int n, id, nbin, temp_bin, num_rest, num_per_bin;
	long double temp1, s1, s2, bin_s;
	double temp, temp2;

	nbin = USE_NBIN;
	/* the code actually uses nbin + 1 bins when there are extra data points.
	   see the num_rest value. */

	data = calloc((total_number*2), sizeof(long double));
	if(data == NULL) {fprintf(stderr, "Memory problem: data\n"); return 1;}

	for(n=0; n < total_number; n++)
	{
			(*(data+(n*2+1))) = (*(norm_mag+n));
	}
	for(n=0; n < total_number; n++)
	{
			temp1 = ((*(date_array+n)) - (*(date_array))) * trial_freq / (2.0 * M_PI);
			*(data+n*2) = modf(temp1, &temp2);
	}
	qsort(data, total_number, 2*sizeof(long double), compare);

	temp = modf((total_number / nbin), &temp2);
	num_per_bin = (int) temp2;
	temp1 = total_number - nbin * temp2;
	num_rest = (int) temp1;
	/* num_per_bin, i.e. temp2 = the number of data points in the bin */
	/* num_rest, i.e. temp1 = the rest of data points */
	if(num_rest > 0) {
		bin_mean = calloc((nbin+1), sizeof(long double));
	} else {
		bin_mean = calloc(nbin, sizeof(long double));
	}

	/* s_1^2 */
	s1 = 0.0;
	for(n=0; n < nbin; n++)
	{
		temp = 0.0;
		for(id=0; id < num_per_bin; id++)
		{
			temp_bin = n * num_per_bin + id;
			temp = temp + *(data+(temp_bin*2+1)); // access the magnitude information
		}
		*(bin_mean+n) = temp / temp2;
		s1 = s1 + temp2 * ( (*(bin_mean+n)) - mean_mag) * ( (*(bin_mean+n)) - mean_mag);
	}
	if( num_rest != 0 )
	{
		temp = 0.0;
		for(id=0; id < num_rest; id++)
		{
			temp_bin = nbin * num_per_bin + id;
			temp = temp + *(data+(temp_bin*2+1));
		}
		*(bin_mean+nbin) = temp / temp1;
		s1 = s1 + temp1 * ( (*(bin_mean+nbin)) - mean_mag) * ( (*(bin_mean+nbin)) - mean_mag);
	}
	if( num_rest == 0) {
		s1 = s1 / (nbin - 1);
	} else {
		s1 = s1 / nbin;
	}
	

	/* s_2^2 */
	s2 = 0.0;
	for(n=0; n < nbin; n++)
	{
		for(id=0; id < num_per_bin; id++)
		{
			temp_bin = n * num_per_bin + id;
			bin_s = *(data+(temp_bin*2+1)) - *(bin_mean+n);
			s2 = s2 + bin_s * bin_s;
		}
	}
	if( num_rest != 0 )
	{
		for(id=0; id < num_rest; id++)
		{
			temp_bin = nbin * num_per_bin + id;
			bin_s = *(data+(temp_bin*2+1)) - *(bin_mean+nbin);
			s2 = s2 + bin_s * bin_s;
		}
	}
	if( num_rest == 0) {
		s2 = s2 / (total_number - nbin);
	} else {
		s2 = s2 / (total_number - nbin - 1);
	}

	free(bin_mean);
	free(data);
	
	return ( s1 / s2 );
}
#endif

int compare(const long double *data1, const long double *data2)
{
		if ( (*data1) < (*data2) )
		{
				return -1;
		}
		else if ( (*data1) == (*data2) )
		{
				return 0;
		}
		else
		{
				return 1;
		}
}

#ifdef USE_RESAMPLE
#ifdef USE_ERR
int jackknife_sample(long double *date_array, long double *mag_array, long double *error_array, int total_number, int out_ind, long double *jackknife_date_array, long double *jackknife_mag_array, long double *jackknife_error_array, long double *new_mean_mag)
{
        int i, k, total_number_minus_1;

        total_number_minus_1 = total_number - 1;

        k = 0;
        for(i=0; i < total_number; ++i) {
                if(i != out_ind) {
                        *(jackknife_date_array + k) = *(date_array + i);
                        *(jackknife_mag_array + k) = *(mag_array + i);
                        *(jackknife_error_array + k) = *(error_array + i);
                        k = k + 1;
                }
        }
        *new_mean_mag = gsl_stats_long_double_wmean(jackknife_error_array, 1, jackknife_mag_array, 1, total_number_minus_1);

        return 0;
}
#else
int jackknife_sample(long double *date_array, long double *mag_array, long double *error_array, int total_number, int out_ind, long double *jackknife_date_array, long double *jackknife_mag_array, long double *jackknife_error_array, long double *new_mean_mag)
{
        int i, k, total_number_minus_1;
        long double ld_temp;

        total_number_minus_1 = total_number - 1;
        
        k = 0;
        ld_temp = 0.0;
        for(i=0; i < total_number; ++i) {
                if(i != out_ind) {
                        *(jackknife_date_array + k) = *(date_array + i);
                        *(jackknife_mag_array + k) = *(mag_array + i);
                        ld_temp = ld_temp + *(jackknife_mag_array + k);
                        *(jackknife_error_array + k) = *(error_array + i);
                        k = k + 1;
                }
        }
        *new_mean_mag = ld_temp / total_number_minus_1;

        return 0;
}
#endif
#endif
