/*****************************************************************************/
/*                                                                           */
/*	spline_dicy.c                                                        */
/*                                                                           */
/*      "spline_dicy" allocates storage for a structure that describes a     */
/*  spline curve with periodic boundary conditions. In addition to the input */
/*  parameters which transmit the original spline curve data, the parameter  */
/*  'byte_alloc' specifies an additional block of free store that may be     */
/*  required by subsidiary routines.                                         */
/*                                                                           */
/*  Arguments:  ni           number of knot intervals in periodic curve      */
/*              nd           dimension of 'xd', 'yd', and 'wd' vectors       */
/*              xd           data coordinates                                */
/*              yd           data coordinates                                */
/*              wd           yd data coordinate standard errors              */
/*              byte_alloc   size of additional memory allocation in bytes   */
/*                                                                           */
/*  Return:     a structure containing a full description of the periodic    */
/*              spline curve. In case of allocation error, s.alloc=NULL. If  */
/*              an insufficient number of data points has been specified,    */
/*              s.ierr=-1.                                                   */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 28, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "spline_inc.h"

static char *message[]={"SPLINE_DICY: storage allocation error\n",
			"SPLINE_DICY: insufficient spline intervals%5i\n",
			"SPLINE_DICY: data points < knot points%5i%5i\n"};

struct spline_dstr spline_dicy(int ni, int nd, double xd[], double yd[],
			       double wd[], int byte_alloc)
{
     int i, nk;
     double *p, u;
     struct spline_dstr s;
     nk=ni+3;
     i=((int) ALIGN(((double*) NULL)+19*nk+4+6*nd+ni*ni, double))+byte_alloc;
     s.nk=nk;
     s.nd=nd;
     s.ierr=0;
     if ((s.alloc=malloc(i)) == NULL)
     {
	  s.ierr=-1;
	  printf(message[0]);
	  return (s);
     }
     s.kn=(p=(double*) s.alloc);
     s.cf=(p+=nk+4);
     s.ov=(p+=nk);
     s.om=(p+=nk);
     s.cm=(p+=4*nk);
     s.dm=(p+=4*nk);
     s.ip=(p+=4*nk);
     s.xd=(p+=4*nk);
     s.yd=(p+=nd);
     s.wd=(p+=nd);
     s.yc=(p+=nd);
     s.lv=(p+=nd);
     s.xt=(p+=nd);
     s.matrix=(p+=nd);
     if (byte_alloc > 0)
     {
	  s.base_a=ALIGN(p+ni*ni, double);
     }
     else
     {
	  s.base_a=NULL;
     }
     if (ni < 1)
     {
	  s.ierr=-1;
	  printf(message[1], ni);
	  return (s);
     }
     else if (nd < ni+1)
     {
	  s.ierr=-1;
	  printf(message[2], nd, ni+1);
	  return (s);
     }
     u=1.0/((double) ni);
     for (i=0; i < nk+4; i++)
     {
	  *(s.kn+i)=((double)(i-3))*u;
     }
     for (i=0; i < nd; i++)
     {
	  *(s.xd+i)=xd[i];
	  *(s.yd+i)=yd[i];
	  if (wd[i] > 0.0)
	  {
	  *(s.wd+i)=1.0/(wd[i]*wd[i]);
	  }
	  else
	  {
	  *(s.wd+i)=0.0;
	  }
	  *(s.xt+i)=xd[i];
     }
     return (s);
}
