/*****************************************************************************/
/*                                                                           */
/*	spline_dbas.c                                                        */
/*                                                                           */
/*      "spline_dbas" computes the value of the four B-spline functions      */
/*  which contribute to the spline curve at point 'x'.                       */
/*                                                                           */
/*  Arguments:  x          coordinate value at which the B-splines are       */
/*                         computed                                          */
/*              nk         number of independent spline coefficients         */
/*              knot       knot vector                                       */
/*              b_spline   B-spline function values                          */
/*                                                                           */
/*  Return:     index 'i' such that x >= knot[i] unless x = knot[nk] in      */
/*              which case (nk-1) is returned. (3 <= i <= (nk-1))            */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              August 27, 1993                                              */
/*                                                                           */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "spline_inc.h"

int spline_dbas(double x, int nk, double knot[], double b_spline[M+1])
{
     int i, j;
     double c[6];
     if ((x < knot[3]) || (x > knot[nk]))
     {
	  printf("SPLINE_DBAS: x value out of range:%12.3f%12.3f%12.3f\n",
		 x, knot[3], knot[nk]);
	  exit(1);
     }
     i=spline_dtbl(x, nk-2, &knot[3])+3;
     if (i == nk)
     {
	  i--;
     }
     for (j=0; j < 4; j++)
     {
	  c[j]=x-knot[i+j-1];
	  c[j]=c[j]*c[j]*c[j];
     }
     c[4]=c[1];
     c[5]=c[2];
     for (j=0; j < 5; j++)
     {
	  if (j != 0)
	  {
	       c[0]=c[0]/(knot[i+j-1]-knot[i-1]);
	       c[1]=c[1]/(knot[i+j]-knot[i]);
	  }
	  if (j != 4)
	  {
	       c[2]=c[2]/(knot[i+j-3]-knot[i+1]);
	       c[3]=c[3]/(knot[i+j-2]-knot[i+2]);
	  }
	  if (j != 1)
	  {
	       c[4]=c[4]/(knot[i+j-1]-knot[i]);
	  }
	  if (j != 3)
	  {
	       c[5]=c[5]/(knot[i+j-2]-knot[i+1]);
	  }
     }
     b_spline[0]=-c[2];
     b_spline[1]=-c[3]-c[5];
     b_spline[2]=+c[0]+c[4];
     b_spline[3]=+c[1];
     for (j=0; j < M+1; j++)
     {
	  b_spline[j]*=knot[i+j+1]-knot[i+j-3];
     }
     return (i);
}
