#!/bin/sh
echo "Light Curve Tool made by Min-Su Shin"

echo "# output : $1.gif"
if [ "$#" = "1" ]; then
		sm_command1=" DATA \"$1\" "
		sm_command2='READ {x 1 y 2} \n LIMITS x y\n LIMITS $fx1 $fx2 $fy2 $fy1\n'
		sm_command3="DEVICE gif $1.gif\n BOX\n POINTS x y\n XLABEL Date\n YLABEL Mag.\n"
		echo $sm_command1 $sm_command2 $sm_command3 | sm
else
		echo "Usage : light_curve_raw.sh [data file name]"
fi

