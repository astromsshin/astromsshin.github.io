#! /usr/bin/env python

import sys, commands, string, os

num_candidate = 10 # users can change the number of candidate period that the final step should consider.

range_factor = 0.0005

period_step_size = 0.00001

def print_usage():
	print "Required arguments:"
	print "... [data filename] [option to store chi^2 values: 0 (not store) or 1 (store)]"
	print "Optional arguments:"
	print "... -n<integer even value> : the number of candidate periods to be considered."
	print "                             The default value is ", num_candidate, "."
	print "... -r<float value> : the multiplication factor to determine the range of trial periods."
	print "                      The trial periods range from P * (1 - this value) to "
	print "                      P * (1 + this value). The default value is ", range_factor, "."
	print "... -s<float value> : the step-size of trial periods."
	print "                      Negative values mean deltaP = a given constant."
	print "                      Positive values mean deltaP/P = a given constant."
	print "                      The default value is ", period_step_size, "."

if( (len(sys.argv) == 3) or (len(sys.argv) == 4) or (len(sys.argv) == 5) or (len(sys.argv) == 6)):
	dataname = sys.argv[1]
	store_chi2_distribution = sys.argv[2]
	# possible optional arguments
	if(len(sys.argv) >= 4):
		for ind in range(3, len(sys.argv)):
			if( (sys.argv[ind])[0] == '-' ):
				if( sys.argv[ind][1] == "n" ):
					num_candidate = int(sys.argv[ind][2:])
				if( sys.argv[ind][1] == "r" ):
					range_factor = float(sys.argv[ind][2:])
				if( sys.argv[ind][1] == "s" ):
					period_step_size = float(sys.argv[ind][2:])
			else:
				print "... wrong arguments."
				print_usage()
				exit()
	num_candidate_half = num_candidate / 2
	lines = commands.getoutput("wc -l "+dataname)
	lines = string.split(lines)
	lines = lines[0]
	filename1 = dataname+'.multi.sort'
	filename2 = dataname+'.phase.sort'
	outfilename = dataname+'.chi2'
	candidate = []
	multi = open(filename1, 'r')
	num_count = 0
	while num_count < num_candidate_half:
		oneline = string.split(multi.readline())
		yesno = candidate.count(float(oneline[0]))
		if yesno == 0:
			candidate.append(float(oneline[0]))
			num_count = num_count + 1
	multi.close()
	phase = open(filename2, 'r')
	num_count = 0
	while num_count < num_candidate_half:
		oneline = string.split(phase.readline())
		yesno = candidate.count(float(oneline[0]))
		if yesno == 0:
			candidate.append(float(oneline[0]))
			num_count = num_count + 1
	phase.close()
	if store_chi2_distribution == "1":
		try:
			os.remove(outfilename)
		except:
			temp = 0
	if store_chi2_distribution != "1":
		outfilename = "?"
	out_str_list = []
	for periods in candidate:
		min_can_period = periods - periods * range_factor
		max_can_period = periods + periods * range_factor
		out_str_list.append(str(min_can_period))
		out_str_list.append(str(periods))
		out_str_list.append(str(max_can_period))
		out_str_list.append(outfilename)
	out_str = string.join(out_str_list)
#	print out_str
	result = commands.getoutput("echo '"+out_str+"' | ./spline "+dataname+" "+str(lines)+" "+str(num_candidate)+" -s"+str(period_step_size))
	result_part = string.split(result, '\n')
	for cnt in range(0, num_candidate) :
		if cnt == 0:
			print "# Result from multi-harmonic function method"
		if cnt == num_candidate_half:
			print "# Result from phase-dispersion minimization"
		single_result = result_part[cnt+1]
		temp = string.split(single_result, '=')
		print temp[4]
else:
	print_usage()
