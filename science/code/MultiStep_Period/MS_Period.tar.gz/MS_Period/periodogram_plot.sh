#!/bin/bash

if [ "$#" = "1" ]; then

echo "# output : $1_power.gif"
sm << ends
device gif "$1_power.gif"
expand 1.2
lweight 1.5
ptype 13 3
data "$1"
read {x 1 y 2}
set x = LG(x)
limits x y
box
xlabel "log_{10} Period"
ylabel "Statistic"
points x y
logout
ends

else

	echo "Usage : periodogram_plot.sh [periodogram file name]"
	echo "Example : periodogram_plot.sh 184010-0047.multi.summary"

fi
