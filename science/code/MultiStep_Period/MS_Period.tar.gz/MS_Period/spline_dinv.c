/*****************************************************************************/
/*                                                                           */
/*	spline_dinv.c                                                        */
/*                                                                           */
/*      "spline_dinv" factors a real symmetric positive definite matrix      */
/*  stored in band form, using the Cholesky decomposition technique. This    */
/*  routine was adapted from "spbfa.f" in the LINPACK library.               */
/*                                                                           */
/*  Arguments:  m        the number of diagonals above the main diagonal     */
/*              n        dimension of original parent square matrix. 'n'     */
/*                       must be greater than 'm'.                           */
/*              matrix   representation of band diagonal matrix. The         */
/*                       diagonals of the original matrix are stored as rows */
/*                       with the m+1 row containing the major diagonal. The */
/*                       data is stored as matrix[n][m+1].                   */
/*                                                                           */
/*  Return:     integer error code. If the value is zero, no error was       */
/*              found; otherwise the value indicates the iteration index     */
/*              when the error was found.                                    */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 29, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include <math.h>
#include "spline_inc.h"

int spline_dinv(int m, int n, double matrix[])
{
     int i, j, k, l, m_1;
     double *mtrx_i, *mtrx_j, s, t;
     m_1=m-1;
     mtrx_i=matrix;
     for (i=0; i < n; i++)
     {
	  s=0.0;
	  mtrx_j=matrix+m*(MAX(i, m_1)-m_1);
	  l=MAX(i, m_1)-i;
	  for (j=l; j < m_1; j++)
	  {
	       k=j-l;
	       t=(*(mtrx_i+j)-spline_ddot(k, mtrx_j+m_1-k, mtrx_i+l))/
		                                               (*(mtrx_j+m_1));
	       *(mtrx_i+j)=t;
	       s+=t*t;
	       mtrx_j+=m;
	  }
	  s=*(mtrx_i+m_1)-s;
	  if (s <= 0.0)
	  {
	       return (++i);
	  }
	  *(mtrx_i+m_1)=sqrt(s);
	  mtrx_i+=m;
     }
     return (0);
}
