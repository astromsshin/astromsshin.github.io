#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int main(int argc, char **argv)
{
	int total_number, id_n;
	FILE *input, *output;
	char *result_file=".fold";
	double *date_array, *mag_array, *error_array, *phase_array;
	double *date_ptr, *mag_ptr, *error_ptr;
	double period,temp;
	char **xd;

	if(argc != 4)
	{
		printf("Usage : fold [3 cols data file name] [number of rows] [Period]\n");
		return 0;
	}
	
	total_number = atoi(argv[2]);

	printf ("Period is %s.\n",argv[3]);
	
	period = atof(argv[3]);

	date_array = calloc(total_number, sizeof(double));
	mag_array = calloc(total_number, sizeof(double));
	error_array = calloc(total_number, sizeof(double));
	phase_array = calloc(total_number, sizeof(double));
	
	input = fopen(argv[1], "r");
	result_file = strcat(argv[1],result_file);
	
/* Read data file with three cols: date, mag., and mag. error */
	
	for(id_n = 0; id_n < total_number; ++id_n) {
			date_ptr = date_array + id_n;
			mag_ptr = mag_array + id_n;
			error_ptr = error_array + id_n;
			fscanf(input,"%lf %lf %lf",date_ptr,mag_ptr,error_ptr);

	}

	fclose(input);
	
	output = fopen(result_file, "w");

	for(id_n = 0; id_n < total_number; ++id_n) {
		*(phase_array+id_n) = ((*(date_array+id_n) - *(date_array))/period);
		modf(*(phase_array+id_n), &temp);
		*(phase_array+id_n) = (*(phase_array+id_n) - temp);
		fprintf(output,"%12lf %12lf %12lf\n",*(phase_array+id_n),*(mag_array+id_n),*(error_array+id_n));
	}
	for(id_n = 0; id_n < total_number; ++id_n) {
		if( (*(phase_array+id_n)) <= 0.5 )
		{
				(*(phase_array+id_n)) = ((*(phase_array+id_n)) + 1.0);
				fprintf(output,"%12lf %12lf %12lf\n",*(phase_array+id_n),*(mag_array+id_n),*(error_array+id_n));
		}
		else
		{
		}
	}
					
	fclose(output);

	free (date_array);
	free (mag_array);
	free (error_array);
	free (phase_array);
	
	return 0;
}
