#!/usr/bin/env python

import numpy
import h5py
import math
from matplotlib import pyplot
from matplotlib import mlab
from matplotlib import cm

# Open the HDF5 file which stores the partial estimate of periodogram.
# sample_hdf5_fn: HDF5 filename.
# This returns HDF5 file descriptor.
def open_sample_file(sample_hdf5_fn):
	in_hdf5_fd = h5py.File(sample_hdf5_fn,'r')
	return in_hdf5_fd

# Extract the partial estimate without a specific data point.
# use_hdf5_fd: HDF5 file descriptor returned by open_sample_file.
# extract_id: the id of the data point which is dropped (starting from 1).
# This returns NumPy array of the statistic estimated without the specific data 
# as a function of trial periods.
def extract_sample_estimate(use_hdf5_fd, extract_id):
	use_dset = use_hdf5_fd.get('/sample'+str(extract_id))
	use_data = use_dset.value # numpy array
	return use_data

# Close the HDF5 file which stores the partial estimate of periodogram.
# use_hdf5_fd: HDF5 file descriptor returned by open_sample_file.
def close_sample_file(use_hdf5_fd):
	use_hdf5_fd.close()
	return

# Read the raw periodogram file which is a two-column ASCII file.
# periodogram_fn: the raw periodogram filename.
# This returns two NumPy arrays which are trial periods and corresponding statistics.
def read_periodogram(periodogram_fn):
	p_value, s_value = numpy.loadtxt(periodogram_fn, usecols=(0,1), unpack=True)
	print "... min. & max. period =", p_value.min(), p_value.max()
	print "... min. & max. stat. =", s_value.min(), s_value.max()
	return p_value, s_value

# Estimate the Jackknife mean of periodogram statistics.
# use_hdf5_fd: HDF5 file descriptor returned by open_sample_file.
# min_id: the starting id of resamples (minimum is 1).
# max_id: the ending id of resamples (maximum is the size of the light curve).
# raw_estimate: the raw periodogram statistics returned by read_periodogram.
# use_period_ind: if this is given, the Jackknife mean is estimated for this specific period.
# This returns the NumPy array or a single value of the Jackknife mean.
def jackknife_mean(use_hdf5_fd, min_id, max_id, raw_estimate, use_period_ind=-1):
	if use_period_ind < 0:
		use_size = raw_estimate.size
		new_estimate = numpy.zeros((use_size), dtype=numpy.longdouble)
		for ind in range(min_id, max_id+1):
			single_sample_estimate = extract_sample_estimate(use_hdf5_fd, ind)
			new_estimate = new_estimate + single_sample_estimate
		new_estimate = new_estimate / (max_id - min_id + 1)
		new_estimate = (max_id - min_id + 1)*raw_estimate - (max_id - min_id)*new_estimate
	else:
		new_estimate = 0.0
		for ind in range(min_id, max_id+1):
			single_sample_estimate = extract_sample_estimate(use_hdf5_fd, ind)
			new_estimate = new_estimate + single_sample_estimate[use_period_ind]
		new_estimate = new_estimate / (max_id - min_id + 1)
		new_estimate = (max_id - min_id + 1)*raw_estimate - (max_id - min_id)*new_estimate
	return new_estimate

# Estimate the Jackknife standard deviation of periodogram statistics.
# use_hdf5_fd: HDF5 file descriptor returned by open_sample_file.
# min_id: the starting id of resamples (minimum is 1).
# max_id: the ending id of resamples (maximum is the size of the light curve).
# use_jackknife_mean: the estimated Jackknife mean returned by jackknife_mean.
# use_period_ind: if this is given, the Jackknife mean is estimated for this specific period.
# This returns the NumPy array or a single value of the Jackknife standard deviation.
def jackknife_std(use_hdf5_fd, min_id, max_id, use_jackknife_mean, use_period_ind=-1):
	if use_period_ind < 0:
		use_size = raw_estimate.size
		use_std = numpy.zeros((use_size), dtype=numpy.longdouble)
		for ind in range(min_id, max_id+1):
			single_sample_estimate = extract_sample_estimate(use_hdf5_fd, ind)
			use_std = use_std + numpy.square(numpy.subtract(single_sample_estimate,use_jackknife_mean))
		use_std = use_std / (max_id - min_id + 1)
		use_std = numpy.sqrt(use_std)
		use_std = (max_id - min_id)*use_std/math.sqrt(max_id - min_id + 1.0)
	else:
		use_std = 0.0
		for ind in range(min_id, max_id+1):
			single_sample_estimate = extract_sample_estimate(use_hdf5_fd, ind)
			use_std = use_std + (single_sample_estimate[use_period_ind] - use_jackknife_mean)\
			*(single_sample_estimate[use_period_ind] - use_jackknife_mean)
		use_std = use_std / (max_id - min_id + 1)
		use_std = math.sqrt(use_std)
		use_std = (max_id - min_id)*use_std/math.sqrt(max_id - min_id + 1.0)
	return use_std

# Plot 2D image where x-axis is a trial period and y-axis is a periodogram statistic for each sample.
# period_min: the minimum range of the trial periods.
# period_max: the maximum range of the trial periods.
# use_periodogram_fn: the raw periodogram filename.
# use_hdf5_fn: HDF5 filename.
# save_tag: if this is True, the plot is saved.
# save_figfn: the filename of the figure which is saved when save_tag is True. The default name is sample_stat_2d.png.
def plot_sample_stat_2d(period_min, period_max, use_periodogram_fn, use_hdf5_fn, save_tag=False, save_figfn="sample_stat_2d.png"):
	use_p_value, use_s_value = read_periodogram(use_periodogram_fn)
	use_array_ind = numpy.where(numpy.logical_and(use_p_value>=period_min, use_p_value<=period_max))
	period_size = use_array_ind[0].size # x-size
	use_p_array = use_p_value[use_array_ind]
	print "... period size ", period_size
	use_hdf5_fd = open_sample_file(use_hdf5_fn)
	sample_size = len(use_hdf5_fd.keys()) # the index starts from 1 to n # y-size
	print "... sample size ", sample_size
	sample_stat_arr_2d = numpy.zeros(shape=(sample_size,period_size))
	for ind in range(0, sample_size):
		temp_data = extract_sample_estimate(use_hdf5_fd, ind+1)
		use_val = temp_data[use_array_ind]
		sample_stat_arr_2d[ind,:] = use_val
	close_sample_file(use_hdf5_fd)
	pyplot.clf()
	pyplot.imshow(numpy.log(sample_stat_arr_2d), interpolation='none', cmap=cm.jet, aspect='auto', origin='lower')
	locs, labels = pyplot.xticks()
	new_xlabels = []
	new_xloc = []
	for ind in range(1,len(locs)-1):
		new_xloc.append(locs[ind])
		new_xlabels.append(str(use_p_array[int(locs[ind])]))
	pyplot.xticks(new_xloc, new_xlabels)
	pyplot.xlabel('Period')
	pyplot.ylabel('Resampling index')
	clbar = pyplot.colorbar(orientation='horizontal')
	clbar.set_label("log(Partial estimation)")
	if not save_tag:
		pyplot.show()
	else:
		pyplot.savefig(save_figfn)
	return

# Plot a histogram where x-axis is a periodogram statistic for each sample for a given trial period.
# use_period: the trial period.
# use_periodogram_fn: the raw periodogram filename.
# use_hdf5_fn: HDF5 filename.
# nbin: the number of bins.
# save_tag: if this is True, the plot is saved.
# save_figfn: the filename of the figure which is saved when save_tag is True. The default name is sample_stat_hist.png.
def plot_sample_stat_hist(use_period, use_periodogram_fn, use_hdf5_fn, nbin=10, save_tag=False, save_figfn="sample_stat_hist.png"):
	use_p_value, use_s_value = read_periodogram(use_periodogram_fn)
	for ind in range(1, use_p_value.size):
		if((use_p_value[ind-1] > use_period) and (use_p_value[ind] <= use_period)):
			found_ind = ind
			break
	raw_s_value = use_s_value[found_ind]
	raw_p_value = use_p_value[found_ind]
	print "... index ", found_ind, " original P ", raw_p_value, " S ", raw_s_value
	use_hdf5_fd = open_sample_file(use_hdf5_fn)
	sample_size = len(use_hdf5_fd.keys()) # the index starts from 1 to n
	hist_input_data = []
	for ind in range(0, sample_size):
		temp_data = extract_sample_estimate(use_hdf5_fd, ind+1)
		use_val = temp_data[found_ind]
		hist_input_data.append(use_val)
	print "... min. and max. S from samples ", min(hist_input_data), max(hist_input_data)
	pyplot.clf()
	n, bins, patches = pyplot.hist(hist_input_data, nbin, facecolor='g', alpha=0.5)
	mu = jackknife_mean(use_hdf5_fd, 1, sample_size, raw_s_value, use_period_ind=found_ind)
	sigma = jackknife_std(use_hdf5_fd, 1, sample_size, mu, use_period_ind=found_ind)
	close_sample_file(use_hdf5_fd)
	if use_p_value.size != mu.size :
		print "ERROR: the sizes of the search periods are not same in ", use_periodogram_fn, \
		"(", use_p_value.size, ") ", use_hdf5_fn, "(", mu.size , ")"
		return
	print "... mean and std of the new S ", mu, sigma
	gauss_y = mlab.normpdf(bins, mu, sigma)
	pyplot.plot(bins, gauss_y, 'r--')
	pyplot.xlabel('Sample partial estimate')
	pyplot.ylabel('Fraction')
	use_title = "P="+str(raw_p_value)+",S="+str(raw_s_value)+"(S="+str(mu)+"+-"+str(sigma)+")"
	pyplot.title(use_title)
	if not save_tag:
		pyplot.show()
	else:
		pyplot.savefig(save_figfn)
	return

# Plot a periodogram with the Jackknife mean where x-axis is a trial period and y-axis is a periodogram statistic.
# use_periodogram_fn: the raw periodogram filename.
# use_hdf5_fn: HDF5 filename.
# save_tag: if this is True, the plot is saved.
# save_figfn: the filename of the figure which is saved when save_tag is True. The default name is sample_jackknife_mean.png.
def plot_sample_jackknife_mean(use_periodogram_fn, use_hdf5_fn, save_tag=False, save_figfn="sample_jackknife_mean.png"):
	use_p_value, use_s_value = read_periodogram(use_periodogram_fn)
	min_p_value = numpy.min(use_p_value)
	max_p_value = numpy.max(use_p_value)
	min_value = numpy.min(use_s_value)
	max_value = numpy.max(use_s_value)
	use_hdf5_fd = open_sample_file(use_hdf5_fn)
	sample_size = len(use_hdf5_fd.keys())
	mu = jackknife_mean(use_hdf5_fd, 1, sample_size, use_s_value)
	jackknife_min_value = numpy.min(mu)
	jackknife_max_value = numpy.max(mu)
	close_sample_file(use_hdf5_fd)
	if use_p_value.size != mu.size :
		print "ERROR: the sizes of the search periods are not same in ", use_periodogram_fn, \
		"(", use_p_value.size, ") ", use_hdf5_fn, "(", mu.size , ")"
		return
	print "... original estimation min. & max. S ", min_value, max_value
	print "... Jackknife estimation min. & max. S ", jackknife_min_value, jackknife_max_value
	pyplot.clf()
	pyplot.semilogx(use_p_value, mu, color='b')
	pyplot.xlim(min_p_value, max_p_value)
	current_ylim1, current_ylim2 = pyplot.ylim()
	pyplot.ylim(jackknife_min_value, current_ylim2)
	pyplot.xlabel("Period")
	pyplot.ylabel("Statistic")
	pyplot.grid(color='r', linestyle='-', which='major', axis='x')
	pyplot.grid(color='r', linestyle='--', which='minor', axis='x')
	if not save_tag:
		pyplot.show()
	else:
		pyplot.savefig(save_figfn)
	return

# Output a periodogram with the Jackknife mean where the first column is a trial period 
# and the second column is a periodogram statistic.
# use_periodogram_fn: the raw periodogram filename.
# use_hdf5_fn: HDF5 filename.
# save_tag: if this is True, the output is saved as a file. If not, two columns are returned.
# save_outfn: the filename of the output which is saved when save_tag is True. The default name is sample_jackknife_mean.txt.
def output_sample_jackknife_mean(use_periodogram_fn, use_hdf5_fn, save_tag=False, save_outfn="sample_jackknife_mean.txt"):
	use_p_value, use_s_value = read_periodogram(use_periodogram_fn)
	use_hdf5_fd = open_sample_file(use_hdf5_fn)
	sample_size = len(use_hdf5_fd.keys())
	mu = jackknife_mean(use_hdf5_fd, 1, sample_size, use_s_value)
	close_sample_file(use_hdf5_fd)
	if use_p_value.size != mu.size :
		print "ERROR: the sizes of the search periods are not same in ", use_periodogram_fn, \
		"(", use_p_value.size, ") ", use_hdf5_fn, "(", mu.size , ")"
		return
	if save_tag:
		numpy.savetxt(save_outfn, numpy.transpose((use_p_value, mu)), delimiter=" ")
		return
	else:
		return use_p_value, mu
