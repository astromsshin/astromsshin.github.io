/*****************************************************************************/
/*                                                                           */
/*	spline_dlse.c                                                        */
/*                                                                           */
/*      "spline_dlse" computes the partial derivative terms of the squared   */
/*  residual error and the corresponding error vector. This code was adapted */
/*  from the routine, "stxwx.f", written by Finbarr O'Sullivan and provided  */
/*  by Philip Spector.                                                       */
/*                                                                           */
/*  Arguments:  nk              number of independent spline coefficients    */
/*              knot            knot vector                                  */
/*              nd              dimension of 'xd', 'yd', and 'wd' vectors    */
/*              xd              data coordinates                             */
/*              yd              data coordinates                             */
/*              wd              yd data coordinate weights                   */
/*              observ_vector   storage for residual error vector            */
/*              observ_matrix   storage for residual error partial           */
/*                              derivatives                                  */
/*                                                                           */
/*  Return:     void                                                         */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 28, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include "spline_inc.h"

void spline_dlse(int nk, double knot[], int nd, double xd[], double yd[],
		 double wd[], double obsrv_vector[],
		 double obsrv_matrix[][M+1])
{
     int i, id, j, k;
     double d[M+1];
     for (i=0;  i < nk; i++)
     {
	  obsrv_vector[i]=0.0;
	  for (j=0; j < M+1; j++)
	  {
	       obsrv_matrix[i][j]=0.0;
	  }
     }
     for (id=0; id < nd; id++)
     {
	  i=spline_dbas(xd[id], nk, knot, d);
	  for (j=0; j < M+1; j++)
	  {
	       obsrv_vector[i+j-3]+=wd[id]*d[j]*yd[id];
	       for (k=0; k < M+1-j; k++)
	       {
		    obsrv_matrix[i+j+k-3][M-j]+=wd[id]*d[k]*d[k+j];
	       }
	  }
     }
     return;
}
