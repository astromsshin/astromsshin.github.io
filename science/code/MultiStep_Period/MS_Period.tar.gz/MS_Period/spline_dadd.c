/*****************************************************************************/
/*                                                                           */
/*	spline_dadd.c                                                        */
/*                                                                           */
/*      "spline_dadd" adds the product of the constant 'x' and vector 'a' to */
/*  vector 'b'. This routine was adapted from "saxpy.f" in the BLAS library. */
/*                                                                           */
/*  Arguments:  n   dimension of vector 'a' and vector 'b'                   */
/*              x   floating point constant which multiplies 'a'             */
/*              a   vector 'a'                                               */
/*              b   vector 'b'                                               */
/*                                                                           */
/*  Return:     void                                                         */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 21, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include "spline_inc.h"

void spline_dadd(int n, double x, double vector_a[], double vector_b[])
{
     int i;
     for (i=0; i < n; i++)
     {
	  vector_b[i]+=x*vector_a[i];
     }
     return;
}
