/*****************************************************************************/
/*                                                                           */
/*	spline_dpls.c                                                        */
/*                                                                           */
/*      "spline_dpls" computes the coefficients of a periodic spline curve   */
/*  specified by the data structure pointed to by 's'. This routine performs */
/*  a simple least square evaluation of the spline coefficients without      */
/*  inclusion of the spline curvature term.                                  */
/*                                                                           */
/*  Arguments:  s  pointer to data structure                                 */
/*                                                                           */
/*  Return:     chi square statistic for spline curve                        */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Randall Laboratory of Physics                                */
/*              500 East University                                          */
/*              University of Michigan                                       */
/*              Ann Arbor, Michigan  48109                                   */
/*                                                                           */
/*              January 30, 1996                                             */
/*                                                                           */
/*****************************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "spline_inc.h"

static char *message[]={"SPLINE_DPLS: no matrix storage allocation\n"};

double spline_dpls(struct spline_dstr *s)
{
     int i, ir, j, jr, ni, nk;
     double *p,*q, u;
     if (s->matrix == NULL)
     {
	  printf(message[0]);
	  exit(1);
     }
     spline_dlse(s->nk, s->kn, s->nd, s->xd, s->yd, s->wd, s->ov, 
		(void*) s->om);
     nk=s->nk;
     ni=nk-3;
     for (i=0; i < ni; i++)
     {
	  *(s->cf+i)=*(s->ov+i);
     }
     for (i=ni; i < nk; i++)
     {
	  *(s->cf+i%ni)+=*(s->ov+i);
     }
     p=s->matrix;
     q=s->om;
     for (i=0; i < ni; i++)
     {
	  for (j=0; j < ni; j++)
	  {
	       *(p+j)=0.0;
	  }
	  for (j=0; j < 4; j++)
	  {
	       *(p+(j+4*ni-4)%ni)+=*(q++);
	  }
	  p+=ni;
     }
     p=s->matrix+ni-1;
     for (i=ni; i < nk; i++)
     {
	  ir=i%ni;
	  for (j=0; j < 4; j++)
	  {
	       jr=(i+j+3*ni-3)%ni;
	       if (ir < jr)
	       {
		    *(p+ir+(ni-1)*jr)+=*(q++);
	       }
	       else
	       {
		    *(p+jr+(ni-1)*ir)+=*(q++);
	       }
	  }
     }
     if ((s->ierr=spline_dinv(ni, ni, s->matrix)) != 0)
     {
	  return (s->chisq=-1.0);
     }
     spline_dmul(ni, ni, s->matrix, s->cf);
     for (i=ni; i < nk; i++)
     {
	  *(s->cf+i)=*(s->cf+i%ni);
     }
     s->chisq=0.0;
     for (i=0; i < s->nd; i++)
     {
	  *(s->yc+i)=spline_dval(*(s->xd+i), s);
	  u=*(s->yc+i)-*(s->yd+i);
	  s->chisq+=*(s->wd+i)*u*u;
     }
     return (s->chisq);
}
