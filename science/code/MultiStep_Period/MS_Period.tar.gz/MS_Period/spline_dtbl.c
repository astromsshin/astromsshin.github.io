/*****************************************************************************/
/*                                                                           */
/*	spline_dtbl.c                                                        */
/*                                                                           */
/*      "spline_dtbl" is a binary lookup routine to determine the index      */
/*  within an array that spans the input argument, 'x'. This routine was     */
/*  adapted from the "locate" code described in "Numerical Recipes in C,     */
/*  Second Edition" by Press, Teukolsky, Vetterling & Flannery (see p. 117). */
/*                                                                           */
/*  Arguments:  x        value to be compared with elements of 'vector'      */
/*              n        number of elements of 'vector'                      */
/*              vector   ordered table of values                             */
/*                                                                           */
/*  Return:     index in 'vector' such that (vector[i] <= x < vector[i+1])   */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 30, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include "spline_inc.h"

int spline_dtbl(double x, int n, double vector[])
{
     int ih, il, im;
     il=0;
     ih=n;
     while ((ih-il) > 1)
     {
	  im=(il+ih) >> 1;
	  if (x < vector[im])
	  {
	       ih=im;
	  }
	  else
	  {
	       il=im;
	  }
     }
     return (il);
}
