/*****************************************************************************/
/*                                                                           */
/*	spline_dend.c                                                        */
/*                                                                           */
/*      "spline_dend" deallocates the free storage assigned to the data      */
/*  structure pointed to by the argument, 's'.                               */
/*                                                                           */
/*  Argument:   s   pointer to spline data structure                         */
/*                                                                           */
/*  Return:     void                                                         */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 22, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "spline_inc.h"

void spline_dend(struct spline_dstr *s)
{
     if (s->alloc != NULL)
     {
	  free(s->alloc);
     }
     return;
}
