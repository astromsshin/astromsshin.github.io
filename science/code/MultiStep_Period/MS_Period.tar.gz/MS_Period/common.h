#define DEFAULT_dP_over_P 0.001

#define USE_DEGREE 6.0

#define USE_NBIN 10

void usage_option(void)
{
	printf("Required command-line inputs:\n");
	printf("  [3 cols data file name] [number of rows]\n");
	printf("Optional command-line inputs:\n");
	printf(" -l<value> low trial period (e.x. -l0.41)\n");
	printf(" -h<value> high trial period (e.x. -h40.3)\n");
	printf(" -s<value> trial period step-size\n");
	printf("           Negative values mean deltaP = a given constant (e.x. -s-0.01).\n");
	printf("           Positive values mean deltaP/P = a given constant (e.x. -s0.01).\n");
	printf("           The default value is %f.\n", DEFAULT_dP_over_P);
	printf(" -a<value> multiplication factor of low trial period (e.x. -a0.5)\n");
	printf("           The default value is 1, i.e. no effect.\n");
	printf(" -b<value> multiplication factor of high trial period (e.x. -b2.0)\n");
	printf("           The default value is 1, i.e. no effect.\n");
}

int parse_option(int argc, char *argv[], int *opt_tag, long double *opt_value)
{
	while(argc > 1) {
		if(argv[argc-1][0] == '-') {
			switch (argv[argc-1][1])
			{
				case 'l':
					opt_tag[0] = 1;
					opt_value[0] = atof(&argv[argc-1][2]);
					break;
				case 'h':
					opt_tag[1] = 1;
					opt_value[1] = atof(&argv[argc-1][2]);
					break;
				case 's':
					opt_value[2] = atof(&argv[argc-1][2]);
					if(opt_value[2] > 0) {
						opt_tag[2] = 1;
					} else {
						opt_tag[2] = -1;
					}
					break;
				case 'a':
					opt_tag[3] = 1;
					opt_value[3] = atof(&argv[argc-1][2]);
					break;
				case 'b':
					opt_tag[4] = 1;
					opt_value[4] = atof(&argv[argc-1][2]);
					break;
				default:
					printf("Wrong arguments %s.\n", argv[argc-1]);
					return 1;	
			}
		}
		argc = argc - 1;
	}
	if((opt_tag[0] != 0) && (opt_tag[1] != 0)) {
		if(opt_value[0] > opt_value[1]) {
			printf("Minimum period is larger than maximum period.\n");
			return 1;
		}
	}
	return 0;
}
