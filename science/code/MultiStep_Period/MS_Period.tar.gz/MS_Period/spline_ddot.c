/*****************************************************************************/
/*                                                                           */
/*	spline_ddot.c                                                        */
/*                                                                           */
/*      "spline_ddot" computes the dot product of the vector 'a' and the     */
/*  vector 'b'. This routine was adapted from "sdot.f" in the BLAS library.  */
/*                                                                           */
/*  Arguments:  n   dimension of vector 'a' and vector 'b'                   */
/*              a   vector 'a'                                               */
/*              b   vector 'b'                                               */
/*                                                                           */
/*  Return:     vector dot product                                           */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 21, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include "spline_inc.h"

double spline_ddot(int n, double vector_a[], double vector_b[])
{
     int i;
     double s;
     s=0.0;
     for (i=0; i < n; i++)
     {
	  s+=vector_a[i]*vector_b[i];
     }
     return (s);
}
