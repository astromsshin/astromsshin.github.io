#!/usr/bin/env python

import numpy
import math
from matplotlib import pyplot
from matplotlib import mlab
from matplotlib import cm

# Read the raw periodogram file which is a two-column ASCII file.
# periodogram_fn: the raw periodogram filename.
# This returns two NumPy arrays which are trial periods and corresponding statistics.
def read_periodogram(periodogram_fn):
	p_value, s_value = numpy.loadtxt(periodogram_fn, usecols=(0,1), unpack=True)
	print "... min. & max. period =", p_value.min(), p_value.max()
	print "... min. & max. stat. =", s_value.min(), s_value.max()
	return p_value, s_value

# Plot a periodogram with the Jackknife mean where x-axis is a trial period and y-axis is a periodogram statistic.
# use_periodogram_fn: the raw periodogram filename.
# save_tag: if this is True, the plot is saved.
# save_figfn: the filename of the figure which is saved when save_tag is True. The default name is periodogram.png.
# user_min_p: if this is positive, the user minimum value is used to plot the periodogram.
# user_max_p: if this is positive, the user maximum value is used to plot the periodogram.
def plot_periodogram(use_periodogram_fn, save_tag=False, save_figfn="periodogram.png", user_min_p=-1, user_max_p=-1):
	use_p_value, use_s_value = read_periodogram(use_periodogram_fn)
	min_p_value = numpy.min(use_p_value)
	max_p_value = numpy.max(use_p_value)
	min_value = numpy.min(use_s_value)
	max_value = numpy.max(use_s_value)
	print "... estimation min. & max. P ", min_p_value, max_p_value
	print "... estimation min. & max. S ", min_value, max_value
	pyplot.clf()
	if user_min_p > 0:
		min_p_value = user_min_p
	if user_max_p > 0:
		max_p_value = user_max_p
	pyplot.xlim(min_p_value, max_p_value)
	pyplot.ylim(min_value, max_value)
	if (user_min_p < 0) and (user_max_p < 0) :
		pyplot.semilogx(use_p_value, use_s_value, color='b')
	else:
		pyplot.plot(use_p_value, use_s_value, color='b')
	pyplot.xlabel("Period")
	pyplot.ylabel("Statistic")
	pyplot.grid(color='r', linestyle='-', which='major', axis='x')
	pyplot.grid(color='r', linestyle='--', which='minor', axis='x')
	if not save_tag:
		pyplot.show()
	else:
		pyplot.savefig(save_figfn)
	return

# Read the raw light curve file which is a two-column or three-column ASCII file.
# lc_fn: the raw light curve filename.
# err_tag: if err_tag = True, NumPy array of mag. err is also returned.
# This returns two or three NumPy arrays.
def read_lc(lc_fn, err_tag=False):
	if not err_tag:
		date_value, mag_value = numpy.loadtxt(lc_fn, usecols=(0,1), unpack=True)
		return date_value, mag_value
	else:
		date_value, mag_value, err_value = numpy.loadtxt(lc_fn, usecols=(0,1,2), unpack=True)
		return date_value, mag_value, err_value

# Plot a light curve.
# lc_fn: the raw light curve filename.
# plot_err: if plot_err = True, error bars are also plotted.
# save_tag: if this is True, the plot is saved.
# save_figfn: the filename of the figure which is saved when save_tag is True. The default name is lc.png.
def plot_lc(lc_fn, plot_err=False, save_tag=False, save_figfn="lc.png"):
	if not plot_err:
		use_date_value, use_mag_value = read_lc(lc_fn, err_tag=plot_err)
	else:
		use_date_value, use_mag_value, use_err_value = read_lc(lc_fn, err_tag=plot_err)
	print "... estimation min. & max. date ", numpy.min(use_date_value), numpy.max(use_date_value)
	print "... estimation min. & max. mag. ", numpy.min(use_mag_value), numpy.max(use_mag_value)
	pyplot.clf()
	if not plot_err:
		pyplot.plot(use_date_value, use_mag_value, color='b', marker='.', linewidth=0)
	else:
		pyplot.errorbar(use_date_value, use_mag_value, yerr=use_err_value, color='b', marker='.', elinewidth=1, linewidth=0)
	current_ylim1, current_ylim2 = pyplot.ylim()
	pyplot.ylim(current_ylim2, current_ylim1)
	pyplot.xlabel("Date")
	pyplot.ylabel("Mag.")
	pyplot.grid(color='r', linestyle='-', which='major', axis='x')
	pyplot.grid(color='r', linestyle='--', which='minor', axis='x')
	if not save_tag:
		pyplot.show()
	else:
		pyplot.savefig(save_figfn)
	return

# Convert the array of date to the array of phase (ranging from 0 to 1) with a given period.
# in_date_value: NumPy array of date.
# in_period: the given period.
# This returns NumPy array of phase values.
def date_to_phase(in_date_value, in_period):
	frac_part, int_part = numpy.modf((in_date_value - in_date_value[0])/ in_period)
	return frac_part

# Plot a light curve after folding it with a given period.
# lc_fn: the raw light curve filename.
# lc_period: period to fold the light curve.
# plot_err: if plot_err = True, error bars are also plotted.
# save_tag: if this is True, the plot is saved.
# save_figfn: the filename of the figure which is saved when save_tag is True. The default name is lc_phase.png.
def plot_lc_phase(lc_fn, lc_period, plot_err=False, save_tag=False, save_figfn="lc_phase.png"):
	if not plot_err:
		use_date_value, use_mag_value = read_lc(lc_fn, err_tag=plot_err)
	else:
		use_date_value, use_mag_value, use_err_value = read_lc(lc_fn, err_tag=plot_err)
	print "... estimation min. & max. date ", numpy.min(use_date_value), numpy.max(use_date_value)
	print "... estimation min. & max. mag. ", numpy.min(use_mag_value), numpy.max(use_mag_value)
	use_phase_value = date_to_phase(use_date_value, lc_period)
	pyplot.clf()
	if not plot_err:
		pyplot.plot(use_phase_value, use_mag_value, color='b', marker='.', linewidth=0)
	else:
		pyplot.errorbar(use_phase_value, use_mag_value, yerr=use_err_value, color='b', marker='.', elinewidth=1, linewidth=0)
	pyplot.xlim(0.0, 1.0)
	current_ylim1, current_ylim2 = pyplot.ylim()
	pyplot.ylim(current_ylim2, current_ylim1)
	pyplot.xlabel("Phase")
	pyplot.ylabel("Mag.")
	use_title = "P="+str(lc_period)
	pyplot.title(use_title)
	pyplot.grid(color='r', linestyle='-', which='major', axis='x')
	pyplot.grid(color='r', linestyle='--', which='minor', axis='x')
	if not save_tag:
		pyplot.show()
	else:
		pyplot.savefig(save_figfn)
	return

# Plot a light curve after folding it with a given period.
# lc_fn: the raw light curve filename.
# lc_period: period to fold the light curve.
# custom_fn: the custom folded light curve filename which has the first two columns of phase and magnitude.
# plot_err: if plot_err = True, error bars are also plotted.
# save_tag: if this is True, the plot is saved.
# save_figfn: the filename of the figure which is saved when save_tag is True. The default name is lc_phase.png.
def plot_lc_phase_custom(lc_fn, lc_period, custom_fn, plot_err=False, save_tag=False, save_figfn="lc_phase_custom.png"):
	if not plot_err:
		use_date_value, use_mag_value = read_lc(lc_fn, err_tag=plot_err)
	else:
		use_date_value, use_mag_value, use_err_value = read_lc(lc_fn, err_tag=plot_err)
	print "... estimation min. & max. date ", numpy.min(use_date_value), numpy.max(use_date_value)
	print "... estimation min. & max. mag. ", numpy.min(use_mag_value), numpy.max(use_mag_value)
	use_phase_value = date_to_phase(use_date_value, lc_period)
	custom_phase_value, custom_mag_value = numpy.loadtxt(custom_fn, usecols=(0,1), unpack=True)
	pyplot.clf()
	if not plot_err:
		pyplot.plot(use_phase_value, use_mag_value, color='b', marker='.', linewidth=0)
	else:
		pyplot.errorbar(use_phase_value, use_mag_value, yerr=use_err_value, color='b', marker='.', elinewidth=1, linewidth=0)
	pyplot.plot(custom_phase_value, custom_mag_value, color='k', linewidth=2)
	pyplot.xlim(0.0, 1.0)
	current_ylim1, current_ylim2 = pyplot.ylim()
	pyplot.ylim(current_ylim2, current_ylim1)
	pyplot.xlabel("Phase")
	pyplot.ylabel("Mag.")
	use_title = "P="+str(lc_period)
	pyplot.title(use_title)
	pyplot.grid(color='r', linestyle='-', which='major', axis='x')
	pyplot.grid(color='r', linestyle='--', which='minor', axis='x')
	if not save_tag:
		pyplot.show()
	else:
		pyplot.savefig(save_figfn)
	return
