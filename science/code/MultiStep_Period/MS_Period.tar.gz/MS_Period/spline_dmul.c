/*****************************************************************************/
/*                                                                           */
/*	spline_dmul.c                                                        */
/*                                                                           */
/*      "spline_dmul" solves the real symmetric positive definite band       */
/*  system using the factors computed by "spline_dinv". This routine was     */
/*  adapted from "spbsl.f" in the LINPACK library.                           */
/*                                                                           */
/*  Arguments:  m        the number of diagonals above the main diagonal     */
/*              n        dimension of original parent square matrix. 'n'     */
/*                       must be greater than 'm'.                           */
/*              matrix   factored matrix created by "spline_dinv"            */
/*              vector   At entry, input vector, b[n], for the equation:     */
/*                       a[n,n]*x[n] = b[n]. On return, x[n] is stored in    */
/*                       'vector'.                                           */
/*                                                                           */
/*  Return:     void                                                         */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 29, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include "spline_inc.h"

void spline_dmul(int m, int n, double matrix[], double vector[])
{
     int i, im, iv, j, m_1;
     double *mtrx_i;
     m_1=m-1;
     mtrx_i=matrix;
     for (i=0; i < n; i++)
     {
	  j=MIN(m_1, i);
	  im=m_1-j;
	  iv=i-j;
	  vector[i]=(vector[i]-spline_ddot(j, mtrx_i+im, vector+iv))/
	                                                         *(mtrx_i+m_1);
	  mtrx_i+=m;
     }
     for (i=n; i > 0;)
     {
	  mtrx_i-=m;
	  i--;
	  j=MIN(m_1, i);
	  im=m_1-j;
	  iv=i-j;
	  vector[i]/=*(mtrx_i+m_1);
	  spline_dadd(j, -vector[i], mtrx_i+im, vector+iv);
     }
     return;
}
