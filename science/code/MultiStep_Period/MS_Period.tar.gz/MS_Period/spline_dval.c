/*****************************************************************************/
/*                                                                           */
/*	spline_dval.c                                                        */
/*                                                                           */
/*      "spline_dval" computes the value of the spline curve described by    */
/*  the data structure pointed to by 's' at the point, 'x'.                  */
/*                                                                           */
/*  Arguments:  x   point at which the spline curve is to be evaluated       */
/*              s   pointer to data structure                                */
/*                                                                           */
/*  Return:     spline curve value                                           */
/*                                                                           */
/*              Carl W. Akerlof                                              */
/*              Center for Particle Astrophysics                             */
/*              301 Le Conte Hall                                            */
/*              University of California                                     */
/*              Berkeley, California  94720                                  */
/*                                                                           */
/*              June 30, 1993                                                */
/*                                                                           */
/*****************************************************************************/

#include "spline_inc.h"

double spline_dval(double x, struct spline_dstr *s)
{
     int i;
     double b_spline[M+1];
     i=spline_dbas(x, s->nk, s->kn, b_spline);
     return (spline_ddot(M+1, s->cf+i-3, b_spline));
}
