#!/bin/bash
echo "# Multi-Step Period (MS-Period) : tool made by Min-Su Shin"

DEBUG_MODE=0 # If you turn on the debug mode, set this variable to 1.
TIME_MODE=0 # If you want to measure computing time, set TIME_MODE == 1.
            # The computing time is measured for the first step (multi vs. phase) 
            # and the second step w/ spline. This information goes to STDERR 
            # instead of STDOUT.

## Options for the phase minimization and multi-harmonic function fitting methods.
##### Options affecting the range of trial periods.
FACTOR_MIN_MAX_PERIOD=0 # If you limit the range of trial periods in selecting candidate periods 
                        # by using MIN/MAX_PERIOD_REDUCTION, set this variable to 1.
                        # MIN/MAX_PERIOD_REDUCTION is multipled to min. and max. trial periods which are found
                        # automatically or given by MIN/MAX_PERIOD.
MIN_PERIOD_FACTOR=1.0 # Only if you set FACTOR_MIN_MAX_PERIOD to 1, this variable is effective.
MAX_PERIOD_FACTOR=1.0 # Only if you set FACTOR_MIN_MAX_PERIOD to 1, this variable is effective.
CUT_MIN_MAX_PERIOD=0 # If you limit the range of trial periods in selecting candidate periods, set this variable to 1.
                     # The program tests trial periods ranging between MIN_PERIOD*MIN_PERIOD_FACTOR
                     # and MAX_PERIOD*MAX_PERIOD_FACTOR.
MIN_PERIOD=0.10 # Only if you set CUT_MIN_MAX_PERIOD to 1, this variable is effective.
MAX_PERIOD=0.50 # Only if you set CUT_MIN_MAX_PERIOD to 1, this variable is effective.
CHANGE_STEP_SIZE=0 # If you want to manually setup the step size of trial periods, set this to 1.
STEP_SIZE=0.0001 # If this value is positive, the step size is determined by dP/P = this value.
                 # For the negative vlue, the step size dP = ABS(this value).
##### Options to store periodogram values.
STORE_PDG=1 # If you want to save the part of periodogram around peaks +- some number, set STORE_PDG == 1.
STORE_TOP_PEAK=1 # If you want to save only top peaks, set STORE_TOP_PEAK == 1
STORE_PEAK_NUMBER=30 # If STORE_TOP_PEAK == 1, this number of top peaks are saved.
STORE_NUMBER=10 # If you set this number, the twice of this number of points in the periodogram are saved around the peaks.
STORE_FACTOR=0.001 # If STORE_NUMBER == 0, STORE_FACTOR is used to save periodogram.
## Options for the Spline fitting method.
STORE_CHI2=1 # If you want to save the part of reduced chi^2 values over candidate periods, set STORE_CHI2 == 1.
NUM_CANDIDATE=-1 # If you want to change the number of candidate periods reexamined by the second step,
                 # change this number to the number of candidate periods. The default value is found in 
                 # candidate.py. Candidates found by multi is checked first, and then periods from phase are checked.
                 # If these candidates are found in both multi and phase, the second step avoids the situation when
                 # the same candidate period is examined twice. When this value is 0, it uses the default value.
SPLINE_RANGE_CHANGE=0 # If you want to change the range multiplication factor of search periods around
                      # the trial period, set this number to 1.
SPLINE_RANGE_FACTOR=0.0005 # This range factor is used to estimate the low and high values of trials periods 
                           # for the second step around the given candidate periods. The range is from 
                           # P - P*SEARCH_RANGE_FACTOR to P + P*SEARCH_RANGE_FACTOR. The default value is found
                           # in candidate.py. When SPLINE_RANGE_CHANGE!=1, this value is not effective.
SPLINE_STEP_SIZE_CHANGE=0 # If you want to manually setup the step size of trial periods, set this to 1.
SPLINE_STEP_SIZE=0.00001 # This option works in the same way as STEP_SIZE in the above for the Spline fitting
                         # method only if SPLINE_CHANGE_STEP_SIZE==1. If this value is negative, dP = this value 
                         # is used. dP/P = constant is applied when this value is positive.

# show default options
echo "[log] FACTOR_MIN_MAX_PERIOD="$FACTOR_MIN_MAX_PERIOD
echo "[log] MIN_PERIOD_FACTOR="$MIN_PERIOD_FACTOR
echo "[log] MAX_PERIOD_FACTOR="$MAX_PERIOD_FACTOR
echo "[log] CUT_MIN_MAX_PERIOD="$CUT_MIN_MAX_PERIOD
echo "[log] MIN_PERIOD="$MIN_PERIOD
echo "[log] MAX_PERIOD="$MAX_PERIOD
echo "[log] STORE_PDG="$STORE_PDG
echo "[log] STORE_TOP_PEAK="$STORE_TOP_PEAK
echo "[log] STORE_PEAK_NUMBER="$STORE_PEAK_NUMBER
echo "[log] STORE_NUMBER="$STORE_NUMBER
echo "[log] STORE_FACTOR="$STORE_FACTOR
echo "[log] STORE_CHI2="$STORE_CHI2
echo "[log] NUM_CANDIDATE="$NUM_CANDIDATE
echo "[log] SPLINE_RANGE_CHANGE="$SPLINE_RANGE_CHANGE
echo "[log] SPLINE_RANGE_FACTOR="$SPLINE_RANGE_FACTOR
echo "[log] SPLINE_STEP_SIZE_CHANGE="$SPLINE_STEP_SIZE_CHANGE
echo "[log] SPLINE_STEP_SIZE="$SPLINE_STEP_SIZE

if [ "$TIME_MODE" = 1 ]; then
	TIME_CMD="time -v"
else
	TIME_CMD=""
fi

if [ "$#" = "1" ]; then
	line_num=`wc -l $1`
	line_num=${line_num%%$1}
	echo "# $line_num data points in the file $1"
	CMDOPTS=""
	if [ "$FACTOR_MIN_MAX_PERIOD" = 1 ]; then
		CMDOPTS=$CMDOPTS" -a$MIN_PERIOD_FACTOR -b$MAX_PERIOD_FACTOR"
	fi
	if [ "$CUT_MIN_MAX_PERIOD" = 1 ]; then
		CMDOPTS=$CMDOPTS" -l$MIN_PERIOD -h$MAX_PERIOD"
	fi
	if [ "$CHANGE_STEP_SIZE" = 1 ]; then
		CMDOPTS=$CMDOPTS" -s$STEP_SIZE"
	fi
	echo "# 1 - 1. Starting Function Fitting Algorithm"
	$TIME_CMD ./multi $1 $line_num $CMDOPTS
	./minmax $1.multi.pdg -p -m -w 3 > ./$1.multi.temp
	sort -n $1.multi.temp -k2 -o ./$1.multi.sort -r
	echo "# 1 - 2. Starting Phase Folding Algorithm"
	$TIME_CMD ./phase $1 $line_num $CMDOPTS
	./minmax $1.phase.pdg -p -m -w 3 > ./$1.phase.temp
	sort -n $1.phase.temp -k2 -o ./$1.phase.sort -r

	if [ "$STORE_PDG" = 1 ]; then
		echo "# ... save the parts of periodograms"
		if [ "$STORE_TOP_PEAK" = 1 ]; then
			head -n $STORE_PEAK_NUMBER ./$1.multi.sort > ./$1.multi.temp
			head -n $STORE_PEAK_NUMBER ./$1.phase.sort > ./$1.phase.temp
		fi
		# save parts of periodogram around peaks
		./save_pdg.py ./$1.multi.pdg ./$1.multi.temp ./$1.multi.summary $STORE_NUMBER $STORE_FACTOR
		./save_pdg.py ./$1.phase.pdg ./$1.phase.temp ./$1.phase.summary $STORE_NUMBER $STORE_FACTOR
	fi
	if [ "$DEBUG_MODE" != 1 ]; then
		rm -f ./$1.*.pdg ./$1.*.temp
	fi
	echo "# 2. Spline fitting for the candidate periods"
	CMDOPTS=""
	if [ "$NUM_CANDIDATE" -gt 0 ]; then
		CMDOPTS=$CMDOPTS" -n$NUM_CANDIDATE"
	fi
	if [ "$SPLINE_RANGE_CHANGE" = 1 ]; then
		CMDOPTS=$CMDOPTS" -r$SPLINE_RANGE_FACTOR"
	fi
	if [ "$SPLINE_STEP_SIZE_CHANGE" = 1 ]; then
		CMDOPTS=$CMDOPTS" -s$SPLINE_STEP_SIZE"
	fi
	$TIME_CMD ./candidate.py $1 $STORE_CHI2 $CMDOPTS > $1.candidate
	if [ "$DEBUG_MODE" != 1 ]; then
		rm -f ./$1.*.sort
	fi
	echo "# RESULT : initially estimated period, final period, and reduced chi^2"
	cat $1.candidate
else
	echo '[usage] ./period.sh (input filename)'
fi
