#!/usr/bin/env python

import sys
import string

pdg_fn = sys.argv[1]
pdg_peak_fn = sys.argv[2]
output_fn = sys.argv[3]

store_number = int(sys.argv[4])
store_factor = float(sys.argv[5])


pdg_fd = open(pdg_fn,'r')
all_lines = pdg_fd.readlines()
pdg_fd.close()
len_all_lines = len(all_lines)

if store_number < 1 :
	use_cut = int(store_factor * len_all_lines)
	if use_cut == 0:
		use_cut = 1
else:
	use_cut = store_number

print "# ... save +- %d points " % (use_cut)

pdg_peak_fd = open(pdg_peak_fn,'r')
all_peak_lines = pdg_peak_fd.readlines()
pdg_peak_fd.close()
len_all_peak_lines = len(all_peak_lines)

output_fd = open(output_fn,'w')
cnt = 0
total_line = 0
while cnt < len_all_peak_lines:
	one_line = all_peak_lines[cnt]
	temp = one_line.split()
	use_linenum = int(temp[2]) - 1
	output_fd.write("# %s" % one_line)
	use_min = use_linenum - use_cut
	use_max = use_linenum + use_cut
#	if cnt > 0:
#		if use_min <= pre_use_max:
#			use_min = pre_use_max + 1
	if use_min < 0:
		use_min = 0
	if use_max >= len_all_lines:
		use_max = len_all_lines - 1
	line_ind = use_min
	while line_ind <= use_max:
		output_fd.write("%s" % all_lines[line_ind])
		line_ind = line_ind + 1
	total_line = total_line + use_max - use_min + 1
	cnt = cnt + 1
#	pre_use_max = use_max
output_fd.close()

use_fraction = float(total_line) / float(len_all_lines)
print "# ... the fraction %g approximately " % (use_fraction)
