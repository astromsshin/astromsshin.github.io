#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

long double cal_amplitude(long double *date_array, long double *mag_array, int total_number, long double trial_freq);

int compare_fn(const long double *data1, const long double *data2)
{
		if ( (*data1) < (*data2) )
		{
				return -1;
		}
		else if ( (*data1) == (*data2) )
		{
				return 0;
		}
		else
		{
				return 1;
		}
}

long double scale_mag(long double in_mag, int type_id, long double min_mag, long double max_mag, long double mean_mag)
{
	long double out_mag;

	/* case 1 */
	if(type_id == 1) {
		out_mag = (in_mag - min_mag) / (2.0 * (max_mag - min_mag)) - 0.25;
	}
	/* case 2 */
	if(type_id == 2) {
		out_mag = (max_mag - min_mag) * logl(in_mag);
	}
	/* case 3 */
	if(type_id == 3) {
		out_mag = expl(in_mag) / (max_mag - min_mag);
	}
	/* case 4 */
	if(type_id == 4) {
		out_mag = (max_mag - min_mag) * logl( fabsl(in_mag - mean_mag) );
	}
	/* case 5 */
	if(type_id == 5) {
		out_mag = expl( fabsl(in_mag - mean_mag) ) / (max_mag - min_mag);
	}
	/* case 6 */
	if(type_id == 6) {
		out_mag =  logl( fabsl(in_mag - mean_mag) / (max_mag - min_mag) );
	}
	/* case 7 */
	if(type_id == 7) {
		out_mag =  expl( fabsl(in_mag - mean_mag) / (max_mag - min_mag) );
	}
	/* case 8 */
	if(type_id == 8) {
		out_mag =  (in_mag - mean_mag) / (max_mag - min_mag);
	}

	return out_mag;
}

int main(int argc, char **argv)
{
	int total_number, id_n, type_ind;
	FILE *input, *output;
	char *result_file=".length.pdg";
	long double *date_array, *mag_array, *error_array;
	long double min_freq,max_freq,trial_freq,freq_interval;
	long double min_mag,max_mag,mean_mag,temp,temp_freq,F;

	if(argc != 4)
	{
			printf("Usage : phase [3 cols data file name] [number of rows] [scaling type]\n");
			printf("The scaling type ranges from 0 to 8.\n");
			return 0;
	}
	else
	{
	}

	total_number = atoi(argv[2]);
	// from 1 to 8
	type_ind = atoi(argv[3]);

	date_array = calloc(total_number, sizeof(long double));
	mag_array = calloc(total_number, sizeof(long double));
	error_array = calloc(total_number, sizeof(long double));

	input = fopen(argv[1], "r");
	result_file = strcat(argv[1],result_file);
	
/* Read data file with three cols: date, mag., and mag. error */
	
	for(id_n = 0; id_n < total_number; ++id_n) {
			fscanf(input,"%Lf %Lf %Lf",(date_array+id_n),(mag_array+id_n),(error_array+id_n));
	}

	min_mag = 10000.0;
	max_mag = -10000.0;
	mean_mag = 0.0;
	for(id_n = 0; id_n < total_number; ++id_n) {
		if(*(mag_array + id_n) > max_mag) max_mag = *(mag_array + id_n);
		if(*(mag_array + id_n) < min_mag) min_mag = *(mag_array + id_n);
		mean_mag = mean_mag + *(mag_array + id_n);
	}
	mean_mag = mean_mag / (long double) total_number;

/* Rescaling magnitude */
	for(id_n = 0; id_n < total_number; ++id_n) {
		if(type_ind > 0) {
			*(mag_array + id_n) = scale_mag( *(mag_array + id_n), type_ind, min_mag, max_mag, mean_mag );
		}
	}

/* Trial frequency setting */

	temp = (*(date_array+total_number-1)) - (*date_array);
	min_freq = 2.0 * M_PI / temp;
	max_freq = min_freq;
	for(id_n = 0; id_n < (total_number-1); ++id_n) {
			temp_freq = M_PI / (*(date_array+id_n+1) - *(date_array+id_n));
			if ( temp_freq > max_freq ) {
					max_freq = temp_freq;
			}
			else
			{
			}
	}
	if( max_freq > (2.0 * M_PI / 0.000001) )
	{
		max_freq = (2.0 * M_PI / 0.000001);
	}

	printf("# Min f. %Lf Max f. %Lf Min P. %Lf Max P. %Lf\n", min_freq, max_freq, (2.0 * M_PI / max_freq), (2.0 * M_PI / min_freq));

	output = fopen(result_file, "w");
	trial_freq = min_freq;
	temp = 0.0;
/* The following two lines were added to correct some problems. */
	while (trial_freq <= max_freq) {
			F = cal_amplitude(date_array, mag_array, total_number, trial_freq);
			temp = (2.0 * M_PI) / trial_freq;
			fprintf(output,"%.6Lf %.6Lf\n",temp, F);
			freq_interval = trial_freq * 0.001;
			trial_freq = trial_freq + freq_interval;
	} 
					
	fclose(input);
	fclose(output);

	free (date_array);
	free (mag_array);
	free (error_array);
	
	return 0;
}

long double cal_amplitude(long double *date_array, long double *norm_mag, int total_number, long double trial_freq)
{
	long double *data;
	int n, id;
	long double temp, temp1, temp2, s;

	data = calloc((total_number*2), sizeof(long double));
	for(n=0; n < total_number; n++)
	{
			(*(data+(n*2+1))) = (*(norm_mag+n));
	}
	for(n=0; n < total_number; n++)
	{
			temp1 = ((*(date_array+n)) - (*(date_array))) * trial_freq / (2.0 * M_PI);
			*(data+n*2) = modfl(temp1, &temp2);
	}
	qsort(data, total_number, 2*sizeof(long double), compare_fn);

	s = 0.0;
	id = total_number - 1;
	for(n=0; n < id; n++)
	{
		temp1 = powl((*(data+((n+1)*2+1))) - (*(data+(n*2+1))), 2.0);
		temp2 = powl((*(data+((n+1)*2))) - (*(data+(n*2))), 2.0);
		temp = sqrtl(temp1 + temp2);
		s = s + temp;
	}
	n = id;
	temp1 = powl( (*(data+1) - *(data+(n*2+1))), 2.0 );
	temp2 = powl( (*(data) - *(data+(n*2)) + 1.0), 2.0 );
	temp = sqrtl(temp1 + temp2);
	s = s + temp;

	free(data);
	
	return s;
}

