#!/bin/bash

for fn in `cat others.list`
do
	fn=${fn%".fits"}
	echo $fn
	./gregister.sh $fn
done
