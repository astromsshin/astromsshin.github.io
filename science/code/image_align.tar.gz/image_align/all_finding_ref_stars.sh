#!/bin/bash

for fn in `cat file.list`
do
	fn=${fn%".fits"}
	echo $fn
	./finding_ref_stars.sh $fn
done
