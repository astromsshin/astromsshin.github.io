#!/bin/bash

rm -f $2.geomap

paste $1.coord $2.coord > $2.trans

cl << ends 2> /dev/null

geomap input=$2.trans database=$2.geomap interactive=no








logout

ends
