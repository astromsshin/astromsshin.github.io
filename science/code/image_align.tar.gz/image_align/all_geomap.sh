#!/bin/bash

refcoord=`cat ref.list`
refcoord=${refcoord%".fits"}

for fn in `cat others.list`
do
	fn=${fn%".fits"}
	echo $fn
	./geomap.sh $refcoord $fn
done
