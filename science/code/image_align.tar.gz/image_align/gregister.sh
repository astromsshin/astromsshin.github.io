#!/bin/bash

cl << ends

gregister input=$1.fits output=$1r.fits database=$1.geomap transfor=$1.trans








logout

ends
