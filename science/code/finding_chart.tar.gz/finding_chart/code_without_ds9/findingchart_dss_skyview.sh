#!/bin/bash

# Written by Min-Su Shin

# North = up / East = left
# DSS_name is from http://skyview.gsfc.nasa.gov/cgi-bin/survey.pl
# objid is a string.
# ra & dec in deg.
# deg_size in deg.
# pix_size is an odd integer.

convert_path="/usr/bin/convert"
montage_path="/usr/bin/montage"
pix_size=501
center_pix=251
circle_pix=261
DSS_name="DSS"
#DSS_name="DSS+2+Red"

if [ $# == 4 ]
then
	objid=$1
	ra=$2
	dec=$3
	deg_size=$4

	echo "Finding chart : "$objid
	rm -f temp1.jpg temp2.jpg

	wget "http://skyview.gsfc.nasa.gov/cgi-bin/images?Position=$ra,$dec&Survey=$DSS_name&Coordinates=J2000&Return=JPEG&Size=$deg_size&Pixels=$pix_size" -O temp1.jpg >& /dev/null
	$convert_path temp1.jpg -stroke red -strokewidth 2 -fill none \
	-draw "circle $center_pix,$center_pix $circle_pix,$circle_pix" temp2.jpg
	$montage_path -geometry +0+0 -background Yellow -font helvetica -label "$objid" temp2.jpg $objid".jpg"
	rm -f temp1.jpg temp2.jpg
else
	echo "usage : ./findingchart_dss_skyview.sh objid ra(deg) dec(deg) size(deg)"
fi
