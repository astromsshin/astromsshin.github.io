#!/usr/bin/env python

# Developed by Min-Su Shin
# (Department of Astrophysical Sciences, Princeton University)
# to query many objects to Simbad in a batch mode.

# This simple code generates a Simbad batch file
# to stdout. You need to redirect the output to
# a file.
# ./simbad_query_builder.py (list file) > (query file)

import sys
import string

# group_fn : the list file which has coordinates of objects
group_fn = sys.argv[1]
group_fd = open(group_fn, 'r')
all_lines = group_fd.readlines()
group_fd.close()

print 'output console=off'
print 'output script=off'
print 'output error=merge'
print 'set limit 1'
print 'format object fmt1 "%IDLIST(1) | %OTYPELIST(S)"'
print 'result full'
print 'set radius 10s' # if you want to change the search radius

for one_line in all_lines:
	temp = string.split(one_line)
	objid = temp[0] # 1st column : tag to recognize object
	ra = temp[1] # 2nd column : ra in degree
	dec = temp[2] # 3rd column : dec in degree
	print 'query coo '+ra+' '+dec
