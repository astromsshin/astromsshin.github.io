#!/bin/bash

url='http://simbad.harvard.edu/simbad/sim-script'

for infn in `ls $1.*`
do
	file_number=${infn##"$1."}
	outfn=$2".$file_number"
	echo $infn $outfn
	curl -F "scriptFile=@$infn" "$url" -o $outfn
done
