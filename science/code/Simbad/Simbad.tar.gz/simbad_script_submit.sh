#!/bin/bash

# Developed by Min-Su Shin
# (Department of Astrophysical Sciences, Princeton University)
# to submit batch jobs to Simbad.

# The first argument is the query file which can be generated 
# by simbad_query_builder.py.
# The second argument is the output filename.

# This simple shell script uses curl. If you know how to use
# libcurl in Python or other languages, you can easily develope
# your own tool in those languages.

infn=$1
outfn=$2
echo $infn $outfn
curl -F "scriptFile=@$infn" 'http://simbad.harvard.edu/simbad/sim-script' -o $outfn
