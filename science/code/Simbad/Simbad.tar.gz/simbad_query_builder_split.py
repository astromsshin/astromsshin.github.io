#!/usr/bin/env python

# Developed by Min-Su Shin
# (Department of Astrophysical Sciences, Princeton University)
# to query many objects to Simbad in a batch mode.

# This simple code generates a Simbad batch file
# to stdout. You need to redirect the output to
# a file.
# ./simbad_query_builder_split.py (list file) (output file prefix)

import sys
import string

# the following number is used to split coordinates.
split_num = 10000

position_fn = sys.argv[1]
position_fd = open(position_fn, 'r')
all_lines = position_fd.readlines()
position_fd.close()

num_objects = len(all_lines)
num_loop = num_objects // split_num + 1

print "# number of query files = %d for %d objects" % (num_loop, num_objects)


for loop_ind in range(0, num_loop):

	out_fn = "%s.%d" % (sys.argv[2], loop_ind+1)
	out_fd = open(out_fn, 'w')

	print "# files = ", position_fn, out_fn

	out_fd.write('output console=off\n')
	out_fd.write('output script=off\n')
	out_fd.write('output error=merge\n')
	out_fd.write('set limit 1\n')
	out_fd.write('format object fmt1 "%IDLIST(1) | %OTYPELIST(S)"\n')
	out_fd.write('result full\n')
	out_fd.write('set radius 6s\n')

	start_ind = loop_ind*split_num
	end_ind = start_ind + split_num - 1
	if end_ind > (num_objects-1):
		end_ind = num_objects - 1

	print "# objects from %d to %d" % (start_ind + 1, end_ind + 1)
	for one_line in all_lines[start_ind:end_ind+1]:
		temp = string.split(one_line)
		objid = temp[0]
		ra = temp[1]
		dec = temp[2]
		out_fd.write('query coo '+ra+' '+dec+'\n')

	out_fd.close()
