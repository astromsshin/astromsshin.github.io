from distutils.core import setup, Extension
setup(name='PyCos',
	version='1.2',
	description='Python for Cosmology',
	author='Min-Su Shin (University of Oxford)',
	author_email='min-su.shin@astro.ox.ac.uk',
	url='http://www.physics.ox.ac.uk/users/msshin/',
	license="GPL",
	long_description='PyCos (Python for Cosmology) implements several calculations of cosmological quantities by using the GNU Scientific library.',
	package_dir = {'': 'src'},
	ext_modules=[Extension('_PyCos', ['src/Cosmology.cpp','src/PyCos.i'], swig_opts=['-modern', '-I ../include'], libraries=['gsl', 'gslcblas'], include_dirs=['include'])],
	py_modules=["PyCos"]
	)
