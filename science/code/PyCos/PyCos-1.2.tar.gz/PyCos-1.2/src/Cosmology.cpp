#include <math.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_sf_gamma.h>
#include "Cosmology.h"

const double D_H_w_h_Mpc = 2997.925;
const double t_H_w_h_year = 9.78e+9;

Cosmology::Cosmology(double o_m, double o_x, double o_k, \
double eos_w_x, double hubble)
{
	omega_m = o_m;
	omega_x = o_x;
	omega_k = o_k;
	w_x = eos_w_x;
	h = hubble;
}

Cosmology::~Cosmology()
{
}

struct E_z_par {
	double omega_m;
	double omega_x;
	double omega_k;
	double w_x;
	double h;
};

/**
 * E_z returns H(z=0) / H(z) for a given z.
 * This is equal to H(z=0) * a / (da/dt).
 */
double E_z(double x, void *params) {
	double omega_m, omega_x, omega_k, w_x, h;
	double fun;
	struct E_z_par *temp;
	temp = (struct E_z_par *) params;

	omega_m = temp->omega_m;
	omega_x = temp->omega_x;
	omega_k = temp->omega_k;
	w_x = temp->w_x;
	h = temp->h;

	if(w_x == -1.0) {
		fun = sqrt(omega_m*(1.0 + x)*(1.0 + x)*(1.0 + x) + \
		omega_k*(1.0 + x)*(1.0 + x) + omega_x);
	} else {
		fun = sqrt(omega_m*(1.0 + x)*(1.0 + x)*(1.0 + x) + \
		omega_k*(1.0 + x)*(1.0 + x) + \
		omega_x*pow((1.0 + x), 3.0*(1.0 + w_x)));
	}
	fun = 1.0/fun;

	return fun;
}

double Cosmology::D_C(double z1, double z2)
{
	double return_val;
	gsl_integration_workspace *w = gsl_integration_workspace_alloc(2000);
	double result, error;
	gsl_function F;
	struct E_z_par temp;

	temp.omega_m = omega_m;
	temp.omega_x = omega_x;
	temp.omega_k = omega_k;
	temp.w_x = w_x;
	temp.h = h;

	F.function = &E_z;
	F.params = &temp;
	gsl_integration_qag(&F, z1, z2, 1.0e-7, 1.0e-8, 2000, 6, w, &result, &error);
	return_val = (D_H_w_h_Mpc / h) * result;
	gsl_integration_workspace_free(w);

	return return_val;
}

double Cosmology::D_M(double z1, double z2)
{
	double return_val;

	if( omega_k == 0.0) {
		return_val = D_C(z1, z2);
		return return_val;
	}

	if( omega_k > 0.0) {
		return_val = sinh(sqrt(omega_k) * D_C(z1, z2) * h / D_H_w_h_Mpc);
		return_val = D_H_w_h_Mpc * return_val / (h * sqrt(omega_k));
		return return_val;
	}
	
	if( omega_k < 0.0) {
		return_val = sin(sqrt(omega_k) * D_C(z1, z2) * h / D_H_w_h_Mpc);
		return_val = D_H_w_h_Mpc * return_val / (h * sqrt(omega_k));
		return return_val;
	}

	return -1.0;
}

double Cosmology::ang_dist(double z)
{
	double return_val;

	return_val = D_M(0.0, z)/(1.0 + z);

	return return_val;
}

double Cosmology::ang_dist_z1_z2(double z1, double z2)
{
	double return_val;

	return_val = D_M(z1, z2) / (1.0 + z2);

	return return_val;
}

double Cosmology::lum_dist(double z)
{
	double return_val;
	
	return_val = D_M(0.0, z) * (1.0 + z);

	return return_val;
}

double Cosmology::unit_comoving_volume(double z, void *params)
{
	double D_A;
	double return_val;
	struct E_z_par temp;

	temp.omega_m = omega_m;
	temp.omega_x = omega_x;
	temp.omega_k = omega_k;
	temp.w_x = w_x;
	temp.h = h;

	D_A = ang_dist(z);
	return_val = (D_H_w_h_Mpc / h) * (1.0 + z) * (1.0 + z);
	return_val = return_val * D_A * D_A * E_z(z, &temp);

	return return_val;
}

double comoving_volume_integral(double z, void *params)
{
	double D_A;
	double return_val;
	struct E_z_par *temp_pt;
	struct E_z_par temp;
	Cosmology tmp;
	temp_pt = (struct E_z_par *) params;

	temp.omega_m = temp_pt->omega_m;
	temp.omega_x = temp_pt->omega_x;
	temp.omega_k = temp_pt->omega_k;
	temp.w_x = temp_pt->w_x;
	temp.h = temp_pt->h;

	tmp = Cosmology(temp.omega_m, temp.omega_x, \
	temp.omega_k, temp.w_x, temp.h);
	D_A = tmp.ang_dist(z);
	return_val = (D_H_w_h_Mpc / temp.h) * (1.0 + z) * (1.0 + z);
	return_val = return_val * D_A * D_A * E_z(z, &temp);

	return return_val;
}


double Cosmology::comoving_volume_z1_z2(double z1, double z2)
{
	gsl_integration_workspace *w = gsl_integration_workspace_alloc(2000);
	double result, error;
	gsl_function F;
	struct E_z_par temp;

	temp.omega_m = omega_m;
	temp.omega_x = omega_x;
	temp.omega_k = omega_k;
	temp.w_x = w_x;
	temp.h = h;

	F.function = &comoving_volume_integral;
	F.params = &temp;
	gsl_integration_qag(&F, z1, z2, 1.0e-7, 1.0e-8, 2000, 6, w, &result, &error);
	gsl_integration_workspace_free(w);

	return result;
}

double Cosmology::comoving_volume_0_z(double z)
{
	double return_val;

	if(omega_k > 0.0) {
		return_val = (D_M(0.0, z) * h / D_H_w_h_Mpc) * \
		sqrt(1.0 + omega_k * (D_M(0.0, z) * h / D_H_w_h_Mpc) * \
		(D_M(0.0, z) * h / D_H_w_h_Mpc));
		return_val = return_val - (1.0/sqrt(fabs(omega_k))) * \
		asinh(sqrt(fabs(omega_k)) * (D_M(0.0, z) * h / D_H_w_h_Mpc));
		return_val = (return_val / 2.0) * \
		(D_H_w_h_Mpc * D_H_w_h_Mpc * D_H_w_h_Mpc) / omega_k;
		return_val = return_val / (h * h * h);

		return return_val;
	}

	if(omega_k < 0.0) {
		return_val = (D_M(0.0, z) * h / D_H_w_h_Mpc) * \
		sqrt(1.0 + omega_k * (D_M(0.0, z) * h / D_H_w_h_Mpc) * \
		(D_M(0.0, z) * h / D_H_w_h_Mpc));
		return_val = return_val - (1.0/sqrt(fabs(omega_k))) * \
		asin(sqrt(fabs(omega_k)) * (D_M(0.0, z) * h / D_H_w_h_Mpc));
		return_val = (return_val / 2.0) * \
		(D_H_w_h_Mpc * D_H_w_h_Mpc * D_H_w_h_Mpc) / omega_k;
		return_val = return_val / (h * h * h);

		return return_val;
	}

	/* omega_k  = 0 */	
	return_val = D_M(0.0, z) * D_M(0.0, z) * D_M(0.0, z) / 3.0;

	return return_val;
}

/**
 * time_integral = 1/(1+z) * H(z=0)/H(z)
 * because dt = 1/H(z) * da/a = -1/H(z) * dz/(1+z)
 *            = 1/(1+z) * -1/H(z) dz
 */
double time_integral(double x, void *params)
{
	double fun;
	struct E_z_par* temp_pt;
	struct E_z_par temp;
	temp_pt = (struct E_z_par *) params;

	temp.omega_m = temp_pt->omega_m;
	temp.omega_x = temp_pt->omega_x;
	temp.omega_k = temp_pt->omega_k;
	temp.w_x = temp_pt->w_x;
	temp.h = temp_pt->h;

	fun = (1.0 / (1.0 + x)) * E_z(x, &temp);

	return fun;
}

/**
 * dt = 1/H(z) * da/a = -1/H(z) * dz/(1+z)
 * \int_{t_now to t} dt(z) = \int_{z=0 to z} dt/dz dz
 * t_now - t(z)  = \int_{z=0 to z} 1/H(z) * dz/(1+z)
 */
double Cosmology::lookback_time(double z)
{
	gsl_integration_workspace *w = gsl_integration_workspace_alloc(2000);
	double result, error;
	gsl_function F;
	struct E_z_par temp;

	temp.omega_m = omega_m;
	temp.omega_x = omega_x;
	temp.omega_k = omega_k;
	temp.w_x = w_x;
	temp.h = h;

	F.function = &time_integral;
	F.params = &temp;
  /**
   * gsl_integration_qag integrates the function over the 
   * finite interval (a, b). This applies an integration rule 
   * adaptively until an estimate of the integral is achieved 
   * within the desired absolute and relative error limits.
   */
	gsl_integration_qag(&F, 0.0, z, 1.0e-7, 1.0e-8, 2000, 6, w, &result, &error);
	result = result * t_H_w_h_year / h;
	gsl_integration_workspace_free(w);
	
	return result;
}

/**
 * dt = 1/H(z) * da/a = -1/H(z) * dz/(1+z)
 * t(z) = \int_{z=infinity to z} dt/dz dz
 * t(z) = \int_{z to infinity} 1/H(z) * dz/(1+z)
 */
double Cosmology::age(double z)
{
	gsl_integration_workspace *w = gsl_integration_workspace_alloc(2000);
	double result, error;
	gsl_function F;
	struct E_z_par temp;

	temp.omega_m = omega_m;
	temp.omega_x = omega_x;
	temp.omega_k = omega_k;
	temp.w_x = w_x;
	temp.h = h;

	F.function = &time_integral;
	F.params = &temp;
  /**
   * gsl_integration_qagiu integrates the function over the 
   * semi-infinite interval (a, +infinity).
   */
	gsl_integration_qagiu(&F, z, 1.0e-7, 1.0e-8, 2000, w, &result, &error);
	result = result * t_H_w_h_year / h;
	gsl_integration_workspace_free(w);
	
	return result;
}

double Cosmology::age_now(void)
{
	double return_val;
	
	return_val = age(0.0);

	return return_val;
}

/**
 * deta = dt/a(t) = dz/a * dt/dz
 *      with dt = 1/H(z) * da/a = -1/H(z) * dz/(1+z)
 *           and dt/dz = -1/H(z) * 1/(1+z)
 * eta(z) = \int_{z to infinity} 1/H(z) dz
 *        where eta(z=infinity) = 0.
 */
double Cosmology::conformal_time(double z)
{
	gsl_integration_workspace *w = gsl_integration_workspace_alloc(2000);
	double result, error;
	gsl_function F;
	struct E_z_par temp;

	temp.omega_m = omega_m;
	temp.omega_x = omega_x;
	temp.omega_k = omega_k;
	temp.w_x = w_x;
	temp.h = h;

	F.function = &E_z;
	F.params = &temp;
  /**
   * gsl_integration_qagiu integrates the function over the 
   * semi-infinite interval (a, +infinity).
   */
	gsl_integration_qagiu(&F, z, 1.0e-7, 1.0e-8, 2000, w, &result, &error);
	result = result * t_H_w_h_year / h;
	gsl_integration_workspace_free(w);
	
	return result;
}

double schechter(double L, double phi_star, double alpha, double L_star)
{
  double return_val;
  L_star = 1.0 / L_star;

  return_val = phi_star;
  return_val = return_val * pow(L*L_star, alpha);
  return_val = return_val * exp(-1.0*L*L_star) * L_star;

  return return_val;
}

double number_schechter(double L, double phi_star, double alpha, double L_star)
{
  double return_val;

  return_val = phi_star * gsl_sf_gamma_inc(alpha+1.0, L/L_star);

	return return_val;
}

double total_number_schechter(double phi_star, double alpha)
{
  double return_val;

  return_val = phi_star * gsl_sf_gamma(alpha+1.0);

	return return_val;
}

double luminosity_schechter(double L, double phi_star, double alpha, double L_star)
{
	double return_val;

	return_val = phi_star * L_star * gsl_sf_gamma_inc(alpha+2.0, L/L_star);

	return return_val;
}

double total_luminosity_schechter(double phi_star, double alpha, double L_star)
{
	double return_val;

	return_val = phi_star * L_star * gsl_sf_gamma(alpha+2.0);

	return return_val;
}

double double_schechter(double L, double phi_star1, double alpha1, \
double L_star1, double phi_star2, double alpha2, double L_star2)
{
  double return_val, temp;

  L_star1 = 1.0 / L_star1;
  return_val = phi_star1;
  return_val = return_val * pow(L*L_star1, alpha1);
  return_val = return_val * exp(-1.0*L*L_star1) * L_star1;
  L_star2 = 1.0 / L_star2;
  temp = phi_star2;
  temp = temp * pow(L*L_star2, alpha2);
  temp = temp * exp(-1.0*L*L_star2) * L_star2;

  return_val = return_val + temp;

  return return_val;
}

double number_double_schechter(double L, double phi_star1, double alpha1, double L_star1, \
double phi_star2, double alpha2, double L_star2)
{
  double return_val;

  return_val = phi_star1 * gsl_sf_gamma_inc(alpha1+1.0, L/L_star1);
  return_val = return_val + phi_star2 * gsl_sf_gamma_inc(alpha2+1.0, L/L_star2);

	return return_val;
}

double luminosity_double_schechter(double L, double phi_star1, double alpha1, double L_star1, \
double phi_star2, double alpha2, double L_star2)
{
	double return_val;

	return_val = phi_star1 * L_star1 * gsl_sf_gamma_inc(alpha1+2.0, L/L_star1);
	return_val = return_val + phi_star2 * L_star2 * gsl_sf_gamma_inc(alpha2+2.0, L/L_star2);

	return return_val;
}

double total_luminosity_double_schechter(double phi_star1, double alpha1, double L_star1, \
double phi_star2, double alpha2, double L_star2)
{
	double return_val;

	return_val = phi_star1 * L_star1 * gsl_sf_gamma(alpha1+2.0);
	return_val = return_val + phi_star2 * L_star2 * gsl_sf_gamma(alpha2+2.0);

	return return_val;
}
