//
// File:	Cosmology.h
// Package:	C++ implementation of cosmology part for PyGL
// Copyright:	the GNU General Public License
// Description:	Cosmology class and other routines supporting PyGL
//


class Cosmology {

	private:
		double omega_m; /**< Omega mass */
		double omega_x; /**< Omega dark energy */
		double omega_k; /**< Omega curvature */
		double w_x; /**< EOS of dark energy */
		double h; /**< parametrized Hubble constant, H = 100h km s^-1 Mpc^-1 */

	public:

		/**
		 * Constructs a cosmological model.
		 * Deafulat values are the concordance LCDM.
		 */
		Cosmology(double o_m=0.260, double omega_x=0.740, \
		double omega_k=0.0, double w_x=-1.0, double h=0.72);
		/**
		 * The destructor does nothing.
		 */
		~Cosmology();

		/**
		 * (Radial) comoving distance.
		 * It returns comoving distance between z1 and z2 in Mpc.
		 */
		double D_C(double z1, double z2);

		/**
		 * Proper distance (aka. transverse comoving distance).
		 * It returns proper distance between z1 and z2 in Mpc.
		 */
		double D_M(double z1, double z2);

		/**
		 * Angular size distance to a given redshift z.
		 * It returns distance in Mpc.
		 */
		double ang_dist(double z);

		/**
		 * Angular size distance between z1 and z2.
		 * It returns distance in Mpc.
		 */
		double ang_dist_z1_z2(double z1, double z2);

		/**
		 * Luminosity distance to a given redshift z.
		 * It returns distance in Mpc.
		 */
		double lum_dist(double z);

		/**
		 * Unit comoving volume at a given redshift z.
		 * It returens volume in Mpc^3 per unit solid 
		 * angle and unit change of redshift.
		 */
		double unit_comoving_volume(double z, void *params);

		/**
		 * Comoving volume between z1 and z2 in 
		 * Mpc^3 per unit solid angle.
		 */
		double comoving_volume_z1_z2(double z1, double z2);

		/**
		 * Comoving volume between z=0 and z in 
		 * Mpc^3 per unit solid angle.
		 */
		double comoving_volume_0_z(double z);

		/**
		 * Lookback time to z in years
		 */
		double lookback_time(double z);

		/**
		 * Cosmic age at z in years
		 */
		double age(double z);

		/**
		 * Cosmic age at z=0 in years
		 */
		double age_now(void);

    /**
     * Conformal time at z in years
     */
    double conformal_time(double z);
};

double E_z(double x, void *params);
double time_integral(double x, void *params);

/**
 * Schechter function phi(L)
 * phi(L) dL = phi_star * (L/L_star)^alpha * exp(-L/L_star) dL / L_star
 * The unit of phi(L) is same as that of phi_star.
 */
double schechter(double L, double phi_star, double alpha, double L_star);

/**
 * the number integration of Schechter function N(>L)
 * N(>L) = Integration of phi(L) from L to infinity 
 * The unit of the returned value depends on the unit of phi_star.
 */
double number_schechter(double L, double phi_star, double alpha, double L_star);

/**
 * the number integration of Schechter function N(>0)
 * N(>0) = Integration of phi(L) from 0 to infinity 
 * The unit of the returned value depends on the unit of phi_star.
 */
double total_number_schechter(double phi_star, double alpha);

/**
 * the luminosity integration of Schechter function L(>L)
 * L(>L) = Integration of L*phi(L) from L to infinity 
 * The unit of the returned value depends on the unit of phi_star.
 */
double luminosity_schechter(double L, double phi_star, double alpha, double L_star);

/**
 * the luminosity integration of Schechter function L(>0)
 * L(>0) = Integration of L*phi(L) from 0 to infinity 
 * The unit of the returned value depends on the unit of phi_star.
 */
double total_luminosity_schechter(double phi_star, double alpha, double L_star);

/**
 * General double Schechter function phi(L)
 * phi(L) dL = phi_star1 * (L/L_star1)^alpha1 * exp(-L/L_star1) dL / L_star1
 *            + phi_star2 * (L/L_star2)^alpha2 * exp(-L/L_star2) dL / L_star2
 * The unit of phi(L) is same as that of phi_star1 and phi_star2.
 */
double double_schechter(double L, double phi_star1, double alpha1, \
double L_star1, double phi_star2, double alpha2, double L_star2);

/**
 * the number integration of double Schechter function N(>L)
 * N(>L) = Integration of phi(L) from L to infinity 
 * The unit of the returned value depends on the unit of phi_star.
 */
double number_double_schechter(double L, double phi_star1, double alpha1, double L_star1, \
double phi_star2, double alpha2, double L_star2);

/**
 * the luminosity integration of double Schechter function L(>L)
 * L(>L) = Integration of L*phi(L) from L to infinity 
 * The unit of the returned value depends on the unit of phi_star.
 */
double luminosity_double_schechter(double L, double phi_star1, double alpha1, double L_star1, \
double phi_star2, double alpha2, double L_star2);

/**
 * the luminosity integration of double Schechter function L(>0)
 * L(>0) = Integration of L*phi(L) from 0 to infinity 
 * The unit of the returned value depends on the unit of phi_star.
 */
double total_luminosity_double_schechter(double phi_star1, double alpha1, double L_star1, \
double phi_star2, double alpha2, double L_star2);
