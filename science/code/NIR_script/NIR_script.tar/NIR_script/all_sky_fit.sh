#!/bin/bash

if [ $# != '1' ]
then
	echo "usage : all_sky_fit.sh (list file of target frames)"
	exit 1
fi

for fn in `cat $1`
do
	echo $fn
	temp=`basename $fn`
	temp=${temp%".fits"}
	new_fn1="./Working/"$temp"_filt.fits"
	new_fn2="./Working/"$temp"_filt_sky.fits"
	new_fn3="./Working/"$temp"_sub.fits"
	new_fn4="./Working/"$temp"_sub_filt.fits"
	new_fn5="./Working/"$temp"_sub_filt_sky.fits"
	new_fn6="./Sky_proc/"$temp"s.fits"
	rm -f $new_fn6 $new_fn5 $new_fn4 $new_fn3 $new_fn2 $new_fn1
	./fit_sky_1st.sh $fn $new_fn1 $new_fn2
cl << ends1

imarith $fn - $new_fn2 $new_fn3

logout

ends1
	./fit_sky_2nd.sh $new_fn3 $new_fn4 $new_fn5
cl << ends2

imarith $new_fn3 - $new_fn5 $new_fn6

logout

ends2

done
