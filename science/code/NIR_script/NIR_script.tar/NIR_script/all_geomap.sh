#!/bin/bash

if [ $# != '2' ]
then
	echo "usage : all_geomap.sh (list of target files excluding the reference image) (the reference image)"
	exit 1
fi

for fn in `cat $1`
do
	fn=`basename $fn`
	fn=${fn%".fits"}
	echo $fn
	temp=`basename $2`
	temp=${temp%".fits"}
	./geomap.sh $temp $fn
done
