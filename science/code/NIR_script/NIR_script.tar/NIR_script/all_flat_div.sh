#!/bin/bash

if [ $# != '2' ]
then
	echo "usage : all_flat_div.sh (list file of target frames) (name of master flat frame)"
	exit 1
fi

for fn in `cat $1`
do
	temp=`basename $fn`
	temp=${temp%".fits"}
	fn=${fn%".fits"}
	echo $fn
	./flat_div.sh $fn $2 $temp
done
