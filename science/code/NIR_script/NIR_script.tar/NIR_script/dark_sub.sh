#!/bin/bash

cl << ends1

imarith $1.fits - $2 ./Dark_proc/$3d.fits

logout

ends1
