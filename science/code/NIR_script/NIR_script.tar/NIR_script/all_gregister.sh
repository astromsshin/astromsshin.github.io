#!/bin/bash

if [ $# != '1' ]
then
	echo "usage : all_gregister.sh (list of target files excexpt fot the reference image)"
	exit 1
fi

for fn in `cat $1`
do
	fn=`basename $fn`
	fn=${fn%".fits"}
	echo $fn
	./gregister.sh $fn
done
