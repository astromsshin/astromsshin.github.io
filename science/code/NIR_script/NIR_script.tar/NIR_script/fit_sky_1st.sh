#!/bin/bash

idl << ends
.r mask_obj.pro
mask_obj, '$1', '$2', nsigma=2.5, psigma=1000.0, bsigma=1.5, nxsub=16, nysub=16, radpix=3, blank=-32768
.r skyfit.pro
skyfit, '$2', '$3', xmedian=128, ymedian=128, func='sfit', order=1, lower=-32767, upper=60000, fraction=0.6
ends
