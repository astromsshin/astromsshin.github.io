#!/bin/bash


if [ $# != '3' ]
then
	echo "usage : coadd.sh (geomap reference image) (list of other files) (name of result file)"
	exit 1
fi

echo $1 >> $$.list
cat $2 >> $$.list

cl << ends

imcombine input=@$$.list output=coadd.fits combine=sum reject=minmax nlow=1 nhigh=1

logout

ends

rm -f $$.list
mv -f coadd.fits  ./Output/$3
