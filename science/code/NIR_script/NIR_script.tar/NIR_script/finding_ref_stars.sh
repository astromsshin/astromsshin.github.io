#!/bin/bash

echo "Select the reference stars in $1.fits using imexam and its a key click"

rm -f ./Working/$1.log ./Working/$1.coord
ds9 ./Sky_proc/$1.fits &

sleep 1

cl << ends 2> /dev/null

imexam input=./Sky_proc/$1.fits logfile=./Working/$1.log keeplog=yes

logout

ends

killall -9 ds9

sleep 1

grep -v "#" ./Working/$1.log | awk -F' ' '{print $1,$2}' > ./Working/$1.coord
