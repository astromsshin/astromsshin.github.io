#!/bin/bash

if [ $# != '2' ]
then
	echo "usage : all_dark_sub.sh (list file of target frames) (name of master dark frame)"
	exit 1
fi

for fn in `cat $1`
do
	temp=`basename $fn`
	temp=${temp%".fits"}
	fn=${fn%".fits"}
	echo $fn
	./dark_sub.sh $fn $2 $temp
done
