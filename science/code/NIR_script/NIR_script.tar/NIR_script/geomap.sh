#!/bin/bash

rm -f ./Working/$2.geomap

paste ./Working/$1.coord ./Working/$2.coord > ./Working/$2.trans

cl << ends 2> /dev/null

geomap input=./Working/$2.trans database=./Working/$2.geomap interactive=no








logout

ends
