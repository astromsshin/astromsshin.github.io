#!/bin/bash

if [ $# != '1' ]
then
	echo "usage : all_finding_ref_stars.sh (list file of target frames)"
	exit 1
fi

for fn in `cat $1`
do
	fn=`basename $fn`
	fn=${fn%".fits"}
	echo $fn
	./finding_ref_stars.sh $fn
done
