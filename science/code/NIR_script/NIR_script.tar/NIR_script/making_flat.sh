#!/bin/bash

if [ $# != '2' ]
then
	echo "usage : making_flat.sh (list file of flat frames) (name of master flat frame)"
	exit 1
fi

rm -f $2 temp$2 mode.txt

cl << ends1 2> /dev/null

imcombine input=@$1 output=temp$2 combine=median scale=none reject=minmax nlow=1 nhigh=1

logout

ends1

cl << ends2 2> /dev/null

imstat images=temp$2 fields=mode nclip=3 lsigma=3.0 usigma=3.0 format=no > mode.txt

logout

ends2

mode=`cat mode.txt`
echo "Mode ="$mode
cl << end3 2> /dev/null

imarith temp$2 / $mode $2

logout

ends3

rm -f mode.txt temp$2
