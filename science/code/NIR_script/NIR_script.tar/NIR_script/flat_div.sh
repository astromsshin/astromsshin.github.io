#!/bin/bash

rm -f ./Flat_proc/$3f.fits

cl << ends1

imarith $1.fits / $2 ./Flat_proc/$3f.fits

logout

ends1
