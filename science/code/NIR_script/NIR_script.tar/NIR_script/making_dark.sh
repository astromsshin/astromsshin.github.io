#!/bin/bash

if [ $# != '2' ]
then
	echo "usage : making_dark.sh (list file of dark frames) (name of master dark frame)"
	exit
fi

rm -f $2

cl << ends1 2> /dev/null

imcombine input=@$1 output=$2 combine=median reject=minmax scale=none

logout

ends1
