#!/bin/bash

cl << ends

gregister input=./Sky_proc/$1.fits output=./Register_proc/$1r.fits database=./Working/$1.geomap transfor=./Working/$1.trans








logout

ends
