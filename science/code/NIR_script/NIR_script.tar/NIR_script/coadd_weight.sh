#!/bin/bash


if [ $# != '3' ]
then
	echo "usage : coadd.sh (geomap reference image) (list of other files) (name of result file)"
	exit 1
fi

echo $1 >> $$.list
cat $2 >> $$.list

cl << ends1

imstat images=@$$.list fields=stddev nclip=5 lsigma=3.0 usigma=3.0 format=no > $$.stddev

logout

ends1

awk -F' ' '{print (1.0/$1)*(1.0/$1)}' $$.stddev > $$.weight
sumweight=`awk -F' ' '{sum += $1} END {print sum}'  $$.weight`
echo $sumweight

fn_list=[]
count=1
for i in `awk -F' ' '{print $1}' $$.list`
do
        fn_list[$count]=$i
        count=$((count+1))
done
weight_list=[]
count=1
for i in `awk -F' ' '{print $1}' $$.weight`
do
        weight_list[$count]=$i
        count=$((count+1))
done

operand1=${fn_list[1]}
operand2=${weight_list[1]}
cl << ends1

imarith $operand1 / $operand2 coadd_weight.fits

logout

ends1

for i in `seq 2 $((count-1))`
do

operand1=${fn_list[$i]}
operand2=${weight_list[$i]}
rm -f $$.fits

cl << ends2 

imarith $operand1 / $operand2 $$.fits

imarith $$.fits + coadd_weight.fits coadd_weight.fits

logout

ends2

done

cl << ends3

imarith coadd_weight.fits / $sumweight coadd_weight.fits

logout

ends3

rm -f $$.list $$.stddev $$.weight $$.fits
mv -f coadd_weight.fits  ./Output/$3
