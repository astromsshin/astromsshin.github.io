#!/bin/bash


if [ $# != '3' ]
then
	echo "usage : combine.sh (geomap reference image) (list of other files) (name of result file)"
	exit 1
fi

echo $1 >> $$.list
cat $2 >> $$.list

cl << ends

imcombine input=@$$.list output=combine.fits combine=median reject=minmax nlow=1 nhigh=1

logout

ends

rm -f $$.list
mv -f combine.fits  ./Output/$3
