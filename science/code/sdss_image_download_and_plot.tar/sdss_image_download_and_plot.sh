#!/bin/bash

##### USER PARAMETERS #####
default_zoom="2.0"
outfn="out.jpg"
default_inst="ds9.reg.slit"
default_band="r"
###########################

if [ $# != '7' ]; then
	echo "usage: $0 (run) (rerun) (camcol) (field) (ra) (dec) (pos. ang. from N to E)"
	exit 0
fi

run=$1
rerun=$2
camcol=$3
field=$4
ra=$5
dec=$6
rot=$7
ra_str=$ra"d"
dec_str=$dec"d"

run_str=`printf "%06d" $run`
field_str=`printf "%04d" $field`

rm -f *.fit.gz $outfn
rm -f ds9.reg
ex $default_inst << ends
%s/RA/$ra/g
%s/DEC/$dec/g
%s/ROT/$rot/g
wq! ds9.reg
ends


fitsfn="fpC-${run_str}-$default_band${camcol}-${field_str}.fit.gz"
if [ $default_band == "u" ]; then
	# u 
	wget "http://das.sdss.org/imaging/${run}/${rerun}/corr/${camcol}/fpC-${run_str}-u${camcol}-${field_str}.fit.gz"
fi
if [ $default_band == "g" ]; then
	# g
	wget "http://das.sdss.org/imaging/${run}/${rerun}/corr/${camcol}/fpC-${run_str}-g${camcol}-${field_str}.fit.gz"
fi
if [ $default_band == "r" ]; then
	# r
	wget "http://das.sdss.org/imaging/${run}/${rerun}/corr/${camcol}/fpC-${run_str}-r${camcol}-${field_str}.fit.gz"
fi
if [ $default_band == "i" ]; then
	# i
	wget "http://das.sdss.org/imaging/${run}/${rerun}/corr/${camcol}/fpC-${run_str}-i${camcol}-${field_str}.fit.gz"
fi
if [ $default_band == "z" ]; then
	# z
	wget "http://das.sdss.org/imaging/${run}/${rerun}/corr/${camcol}/fpC-${run_str}-z${camcol}-${field_str}.fit.gz"
fi

ds9 -grid yes -cmap b -zscale -file $fitsfn -wcs align yes -wcs skyformat degrees -pan to $ra $dec wcs fk5 -zoom $default_zoom -regions strip yes -regions format ds9 -regions load ds9.reg -saveimage jpeg $outfn -exit
